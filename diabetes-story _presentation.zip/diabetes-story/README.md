# From a Single Drop — Diabetes Classification Using Decision Trees

An interactive, 13-slide presentation of our mini project. The data and results all come from
`Diabetes_Decision_Tree (1).ipynb` (Diabetes Dataset, Mendeley Data).

## Run it

No install and no internet needed: every font and script is bundled.

- **Easiest:** double-click `index.html` and open it in Chrome or Edge.
- **Or use a local server:**
  ```bash
  cd diabetes-story
  python -m http.server 8000
  ```
  then open http://localhost:8000.

Press **F** for fullscreen. The deck is authored at 1920×1080 and scales to any 16:9 screen,
with letterboxing on other ratios. To start on a given slide, add `#5` to the URL.

## Controls

| Key | Action |
|---|---|
| → / Space / PageDown | Next (on slide 12 the first press plays the closing) |
| ← / Shift+Space / PageUp | Previous |
| Home / End | First / last slide |
| S | Skip the current animation |
| R | Replay the current animation |
| O | Slide overview |
| N | Speaker-notes drawer |
| P | Separate presenter window (notes, next slide, timer, controls) |
| L | Spotlight that follows the cursor |
| F | Fullscreen |
| Esc | Close any overlay |

The bottom ECG line is the progress bar. Click any heartbeat to jump to that slide. The control bar
hides when the mouse is idle.

## The 13 slides

1. **The First Drop.** Opens for World Diabetes Day. Particles gather into the blue awareness circle, *14 November · World Diabetes Day* appears, and the circle pulses and unrolls into a heartbeat line. Then the original sequence plays: the hand, a lancet tap and one droplet. The droplet becomes a 3-D data network that organises into our real tree, followed by the title and "Prepared by: Shouq, Razan, Fay, Abdullah".
2. **Three Classes.** Three drops become N / P / Y cards. Click a card to see its count and average HbA1c.
3. **How a Tree Thinks.** A hand taps the root of a playable *illustrative* tree. Click any node or branch.
4. **The Dataset.** Counters, then a scanning beam reveals the 14 columns around the classification target, CLASS (N / P / Y). Hover a class or feature.
5. **Imbalance.** One droplet becomes 1,000 dots (one per record) that build an exact bar chart. The question card reveals the 84.4% trap.
6. **The Signal.** Three test strips release their readings onto the HbA1c axis as means and min–max ranges.
7. **Preprocessing.** Records flow through the pipeline (1 dot = 5 records): 1,000 → 825 → 11 features → 660 / 165. Click a stage for details.
8. **Baseline Model — Logistic Regression.** Schematic straight boundaries, plus how the baseline was trained.
9. **Cross-Validation — Finding the Best Depth.** The real mean CV macro-F1 for depths 1–10. Depth 5 scores best (0.947). Hover a column for its score.
10. **Decision Tree — Training with the Selected Depth (5).** The real trained tree. Click nodes or use Yes / No to follow a record to a leaf.
11. **Model Comparison — Logistic Regression vs. Decision Tree.** Glass vessels for Accuracy, Macro F1 and Pre-diabetic recall. Switch metrics with the tabs.
12. **Every Prediction Has a Story.** 165 test tokens fall through the tree into the confusion matrix. Toggle to compare with Logistic Regression.
13. **From Data to Decisions.** Three result-based insights. Then the hand returns, a drop becomes the tree, and the deck closes with "Thank You / Questions?".

Replay (R) on slide 1 replays the whole opening, including World Diabetes Day. Skip (S) jumps straight to the title.

## Data accuracy

- All numbers live in `data.js` and are taken directly from the notebook's printed outputs.
- The trained tree on slide 9 was transcribed from the notebook's `plot_tree` figure: every threshold and every class count.
- Slide 3's tree and slide 8's scatter plots are labelled as illustrations. They are not our data.
- On slide 11, each token's path through the tree is visual only. It lands in a leaf of the class the model predicted.

## Files

```
index.html     slide markup
styles.css     visual system
data.js        every number shown
js/core.js     animation helpers, canvas particles, hand controller, tree layout
js/hand.js     original layered SVG artwork: hand, lancet, test strip
js/scenes-a.js slides 1–6 timelines
js/scenes-b.js slides 7–12 timelines
js/main.js     navigation, transitions, progress monitor, overview, notes, presenter window
js/notes.js    speaker notes
js/wdd-opening.js World Diabetes Day prelude of slide 1 (runs before the original opening)
assets/fonts/  Fraunces, Inter, JetBrains Mono (SIL Open Font License)
```

No external libraries are used. Each scene is a pure function of time, which is why Skip and Replay are exact.
The deck respects the operating system's *reduced motion* setting by showing every slide in its finished state.

*An academic experiment, not a validated diagnostic system.*
