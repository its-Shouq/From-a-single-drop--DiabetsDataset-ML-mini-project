/* ==========================================================================
   main.js — the director: navigation, transitions, chrome, presenter tools.
   ========================================================================== */
(function () {
  const { $, $$, el, svg, clamp, lerp, ease } = K;
  const stage = $("#stage");
  const slides = $$(".slide", stage);
  const N = slides.length;
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const chrome = $(".chrome"), monitor = $(".monitor"), count = $(".count");
  let scale = 1, cur = -1;

  /* ---------------- scaling ---------------- */
  function fit() {
    scale = Math.min(innerWidth / 1920, innerHeight / 1080);
    stage.style.transform = `scale(${scale}) translate(-960px,-540px)`;
    SCENES.forEach(s => s && s._fx && s._fx.forEach(f => f.resize(scale)));
    const sc = SCENES[cur]; if (sc) render(true);
  }
  addEventListener("resize", fit);
  function toStage(e) {
    const r = stage.getBoundingClientRect();
    return { x: (e.clientX - r.left) / scale, y: (e.clientY - r.top) / scale };
  }

  /* ---------------- scene api ---------------- */
  function api(i) {
    const sc = SCENES[i];
    return {
      slide: slides[i],
      fx(canvas) { const f = new K.FX(canvas); f.resize(scale); (sc._fx = sc._fx || []).push(f); return f; },
      toStage,
      reduced,
      next: () => next(),
      kick: () => { clock.kick = true; },          // ask for one extra frame
      get t() { return clock.t; }
    };
  }
  const clock = { start: 0, t: 0, done: false, kick: false };

  function enter(i) {
    const sc = SCENES[i];
    if (!sc) return;
    if (!sc._init) { sc.init(api(i)); sc._init = true; }
    sc.hold = sc.holdAt ?? null;
    sc.enter && sc.enter();
    clock.start = performance.now() + 250;
    clock.done = false; clock.t = 0;
    if (reduced) skip();
    else sc.update(0);
  }
  function skip() {
    const sc = SCENES[cur]; if (!sc) return;
    const end = sc.hold ?? sc.duration;
    clock.start = performance.now() - end * 1000 - 1;
    render(true);
  }
  function replay() { enter(cur); }

  function render(force) {
    const sc = SCENES[cur]; if (!sc) return;
    const now = performance.now();
    let t = Math.max(0, (now - clock.start) / 1000);
    const stopAt = sc.hold ?? sc.duration;
    if (t > stopAt) t = stopAt;
    const moving = t < stopAt || force || clock.kick || !clock.done;
    clock.kick = false;
    if (moving) { clock.t = t; sc.update(t); }
    if (t >= sc.duration && !clock.done) { clock.done = true; sc.done && sc.done(); }
    sc.tick && sc.tick(now);
  }
  function loop() { render(false); monitorTick(); requestAnimationFrame(loop); }

  /** release a scene's hold point (used by the final slide) */
  function release() {
    const sc = SCENES[cur];
    if (sc.hold == null) return false;
    const h = sc.hold; sc.hold = null;
    const t = Math.max(0, (performance.now() - clock.start) / 1000);
    if (t >= h) clock.start = performance.now() - h * 1000;
    return true;
  }

  /* ---------------- navigation + transitions ---------------- */
  let pending = null;
  function go(i, opt = {}) {
    i = clamp(i, 0, N - 1);
    if (pending) pending();                     // finish a running transition at once
    if (i === cur) return;
    const prev = cur, from = slides[prev], to = slides[i];
    const fwd = i > prev;
    const prevScene = SCENES[prev];
    cur = i;
    to.classList.add("on");
    stage.classList.toggle("on-light", to.classList.contains("light"));
    enter(i);
    updateChrome();
    if (prev < 0 || reduced || opt.instant) {
      if (from) { from.classList.remove("on"); prevScene && prevScene.leave && prevScene.leave(); }
      return;
    }
    const o = (fwd && prevScene && prevScene.origin && prevScene.origin()) || { x: 960, y: 540 };
    to.classList.add("enter"); from.classList.add("leave");
    const dur = 1050;
    const a1 = from.animate(
      [{ opacity: 1, transform: "scale(1)", filter: "blur(0px)" },
       { opacity: 0, transform: `scale(${fwd ? 1.04 : .97})`, filter: "blur(6px)" }],
      { duration: dur * .9, easing: "cubic-bezier(.5,0,.2,1)", fill: "forwards" });
    const a2 = fwd
      ? to.animate(
        [{ clipPath: `circle(0px at ${o.x}px ${o.y}px)` }, { clipPath: `circle(2300px at ${o.x}px ${o.y}px)` }],
        { duration: dur, easing: "cubic-bezier(.65,0,.25,1)", fill: "forwards" })
      : to.animate([{ opacity: 0 }, { opacity: 1 }], { duration: dur * .8, easing: "ease-out", fill: "forwards" });
    const finish = () => {
      if (pending !== finish) return;
      pending = null;
      if (from !== slides[cur]) from.classList.remove("on");
      from.classList.remove("leave"); to.classList.remove("enter");
      a1.cancel(); a2.cancel();
      prevScene && prevScene.leave && prevScene.leave();
    };
    pending = finish;
    a2.onfinish = finish;
  }
  function next() {
    const sc = SCENES[cur];
    if (sc && sc.next && sc.next()) return;
    if (sc && sc.hold != null && release()) return;
    go(cur + 1);
  }
  function prev() { go(cur - 1); }

  /* ---------------- ECG progress monitor ---------------- */
  const segW = 1920 / N, baseY = 38;
  let doneW = 0, doneTarget = 0;
  (function buildMonitor() {
    let d = `M0,${baseY}`;
    for (let i = 0; i < N; i++) {
      const c = segW * i + segW / 2;
      const pts = [[-40, 0], [-30, -5], [-22, 0], [-12, 0], [-7, 5], [0, -24], [6, 13], [11, 0], [22, 0], [31, -7], [40, 0]];
      pts.forEach(([dx, dy]) => d += ` L${(c + dx).toFixed(1)},${baseY + dy}`);
    }
    d += ` L1920,${baseY}`;
    const defs = svg("defs", {}, monitor);
    const cp = svg("clipPath", { id: "monDone" }, defs);
    monitor._clip = svg("rect", { x: 0, y: 0, width: 0, height: 60 }, cp);
    svg("path", { d, class: "base" }, monitor);
    svg("path", { d, class: "done", "clip-path": "url(#monDone)" }, monitor);
    monitor._mk = [];
    slides.forEach((s, i) => {
      const g = svg("g", { class: "seg" }, monitor);
      const c = segW * i + segW / 2;
      svg("rect", { x: segW * i, y: 0, width: segW, height: 60, class: "hit" }, g);
      monitor._mk.push(svg("circle", { cx: c, cy: baseY, r: 4, class: "mk" }, g));
      const tx = svg("text", { x: c, y: 10, class: "mlabel", "text-anchor": "middle" }, g);
      tx.textContent = `${i + 1} · ${s.dataset.title}`;
      g.addEventListener("click", () => go(i));
    });
  })();
  function monitorTick() {
    doneW = lerp(doneW, doneTarget, .06);
    if (Math.abs(doneW - doneTarget) > .3) monitor._clip.setAttribute("width", doneW.toFixed(1));
  }

  function updateChrome() {
    count.textContent = `${cur + 1} / ${N}`;
    doneTarget = segW * cur + segW / 2 + 40;
    if (reduced) { doneW = doneTarget; monitor._clip.setAttribute("width", doneW); }
    monitor._mk.forEach((m, i) => { m.classList.toggle("cur", i === cur); m.setAttribute("r", i === cur ? 7 : 4); m.style.opacity = i <= cur ? 1 : .35; });
    $$(".ov-card").forEach((c, i) => c.classList.toggle("cur", i === cur));
    renderNotes();
    presenterSync();
  }

  /* ---------------- overview ---------------- */
  const ov = $(".overview"), ovGrid = $(".ov-grid");
  slides.forEach((s, i) => {
    const b = el("button", "ov-card " + (s.classList.contains("dark") ? "dark" : "light"), ovGrid,
      `<span class="ov-n">${String(i + 1).padStart(2, "0")}</span><span class="ov-t">${s.dataset.title}</span>`);
    b.addEventListener("click", () => { toggleOverview(false); go(i); });
  });
  function toggleOverview(v = ov.hidden) { ov.hidden = !v; btn("overview").classList.toggle("on", v); }

  /* ---------------- speaker notes ---------------- */
  const notes = $(".notes");
  function renderNotes() {
    const n = NOTES[cur] || { title: "", points: [] };
    $(".notes-t", notes).textContent = `${cur + 1}. ${n.title}`;
    $(".notes-b", notes).innerHTML = `<ul>${n.points.map(p => `<li>${p}</li>`).join("")}</ul>`;
  }
  function toggleNotes(v = notes.hidden) { notes.hidden = !v; btn("notes").classList.toggle("on", v); }

  /* presenter window (about:blank shares our origin, so it works from file:// too) */
  let pw = null, t0 = Date.now();
  function openPresenter() {
    if (pw && !pw.closed) { pw.focus(); return; }
    pw = window.open("", "presenter", "width=980,height=720");
    if (!pw) return;
    pw.document.write(`<!doctype html><title>Presenter — From a Single Drop</title>
<style>
body{margin:0;font:18px/1.5 Inter,Segoe UI,system-ui,sans-serif;background:#0A1531;color:#E6EEFA;display:grid;grid-template-rows:auto 1fr auto;height:100vh}
header{display:flex;justify-content:space-between;align-items:center;padding:18px 28px;border-bottom:1px solid #22345e}
h1{font:600 26px Georgia,serif;margin:0}.k{font:600 13px monospace;letter-spacing:.14em;text-transform:uppercase;color:#5BE3F0}
main{padding:20px 28px;overflow:auto;font-size:22px}li{margin-bottom:12px}
footer{display:flex;gap:10px;align-items:center;padding:16px 28px;border-top:1px solid #22345e}
button{font:600 18px Inter,sans-serif;padding:12px 22px;border-radius:999px;border:0;background:#1C3262;color:#fff;cursor:pointer}
button:hover{background:#28457f}#tm{margin-left:auto;font:600 26px monospace;color:#5BE3F0}#nx{color:#8EA0BE}
</style>
<header><div><div class="k" id="k"></div><h1 id="t"></h1></div><div id="nx"></div></header>
<main id="b"></main>
<footer><button id="p">‹ Prev</button><button id="n">Next ›</button><button id="r">↺ Replay</button><button id="s">⏭ Skip</button><span id="tm">00:00</span></footer>`);
    pw.document.close();
    const d = pw.document;
    d.getElementById("p").onclick = () => prev();
    d.getElementById("n").onclick = () => next();
    d.getElementById("r").onclick = () => replay();
    d.getElementById("s").onclick = () => skip();
    d.addEventListener("keydown", onKey);
    t0 = Date.now();
    pw._timer = pw.setInterval(() => {
      const s = Math.floor((Date.now() - t0) / 1000);
      d.getElementById("tm").textContent = `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
    }, 500);
    presenterSync();
  }
  function presenterSync() {
    if (!pw || pw.closed) return;
    const d = pw.document, n = NOTES[cur] || { title: "", points: [] };
    d.getElementById("k").textContent = `Slide ${cur + 1} of ${N}`;
    d.getElementById("t").textContent = n.title;
    d.getElementById("b").innerHTML = `<ul>${n.points.map(p => `<li>${p}</li>`).join("")}</ul>`;
    d.getElementById("nx").textContent = cur < N - 1 ? `Next: ${slides[cur + 1].dataset.title}` : "Last slide";
  }

  /* ---------------- spotlight ---------------- */
  const spot = $(".spot");
  function toggleSpot(v = !spot.classList.contains("on")) { spot.classList.toggle("on", v); btn("spot").classList.toggle("on", v); }
  stage.addEventListener("pointermove", e => {
    const p = toStage(e);
    spot.style.setProperty("--sx", p.x + "px"); spot.style.setProperty("--sy", p.y + "px");
  });

  /* ---------------- fullscreen ---------------- */
  function toggleFS() {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen && document.documentElement.requestFullscreen().catch(() => {});
    else document.exitFullscreen();
  }
  document.addEventListener("fullscreenchange", () => btn("fs").classList.toggle("on", !!document.fullscreenElement));

  /* ---------------- controls ---------------- */
  const btn = c => $(`[data-c="${c}"]`, chrome);
  const actions = {
    prev, next, replay, skip,
    overview: () => toggleOverview(), notes: () => toggleNotes(), presenter: openPresenter,
    spot: () => toggleSpot(), fs: toggleFS
  };
  $$("[data-c]", chrome).forEach(b => b.addEventListener("click", e => { e.stopPropagation(); actions[b.dataset.c](); b.blur(); }));

  let idleT;
  function wake() {
    chrome.classList.remove("idle");
    clearTimeout(idleT);
    idleT = setTimeout(() => chrome.classList.add("idle"), 2600);
  }
  addEventListener("pointermove", wake);

  function onKey(e) {
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    const k = e.key;
    if (k === "Escape") { toggleOverview(false); toggleNotes(false); toggleSpot(false); return; }
    if (!ov.hidden && k !== "o" && k !== "O") return;
    switch (k) {
      case "ArrowRight": case "PageDown": case "ArrowDown": e.preventDefault(); next(); break;
      case " ": e.preventDefault(); e.shiftKey ? prev() : next(); break;
      case "ArrowLeft": case "PageUp": case "ArrowUp": case "Backspace": e.preventDefault(); prev(); break;
      case "Home": go(0); break;
      case "End": go(N - 1); break;
      case "f": case "F": toggleFS(); break;
      case "o": case "O": toggleOverview(); break;
      case "n": case "N": toggleNotes(); break;
      case "p": case "P": openPresenter(); break;
      case "r": case "R": replay(); break;
      case "s": case "S": skip(); break;
      case "l": case "L": toggleSpot(); break;
      default: return;
    }
    wake();
  }
  addEventListener("keydown", onKey);

  /* expose for scenes, the presenter window and automated checks */
  window.DIRECTOR = { go, next, prev, skip, replay, release, get cur() { return cur; }, get scale() { return scale; },
    seek(t) { const sc = SCENES[cur]; clock.start = performance.now() - t * 1000; render(true); } };

  // slides must be visible for the first layout pass, so init every scene once now
  slides.forEach((s, i) => { const sc = SCENES[i]; if (sc && !sc._init) { s.classList.add("on"); sc.init(api(i)); sc._init = true; s.classList.remove("on"); } });

  fit();
  const start = parseInt((location.hash.match(/\d+/) || [1])[0], 10) - 1;
  go(isNaN(start) ? 0 : start, { instant: true });
  wake();
  requestAnimationFrame(loop);
})();
