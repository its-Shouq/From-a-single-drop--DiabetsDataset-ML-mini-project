/* ==========================================================================
   scenes-a.js — slides 1–6
   ========================================================================== */
(function () {
  const { clamp, lerp, seg, ease, rng, mix, C, KEYS, svg, el, $, $$, style, rise, Hand, layoutTree, edgeD, edgePt, pathTo } = K;
  const D = window.DATA;

  /** wrap artwork so the element's (0,0) is the artwork point (ox, oy) */
  function prop(elm, html, ox, oy) {
    elm.innerHTML = `<div style="position:absolute;left:${-ox}px;top:${-oy}px">${html}</div>`;
    elm.style.transformOrigin = "0 0";
  }
  const lum = k => C[k + "L"];

  /* ======================================================================
     1 · THE FIRST DROP
     ====================================================================== */
  SCENES[0] = {
    duration: 16,
    init(api) {
      const s = this.s = api.slide;
      this.fx = api.fx($("canvas", s));
      this.cam = $(".s1-cam", s);
      this.hand = new Hand($(".s1-hand", s), { width: 1150 });
      this.lancet = $(".s1-lancet", s); prop(this.lancet, Art.lancetSVG(), 60, 10);
      this.strip = $(".s1-strip", s); prop(this.strip, Art.stripSVG("#F3E6E3"), 4, 36);
      this.stripPad = $(".strip-pad", this.strip);
      this.title = $$(".s1-title > *", s).concat($$(".s1 h1 span", s));
      this.eyebrow = $(".eyebrow", s); this.h1a = $(".l1", s); this.h1b = $(".l2", s);
      this.sub = $(".sub", s); this.acts = $(".s1-actions", s); this.note = $(".s1-note", s); this.skipB = $(".s1-skip", s);
      $(".s1 h1", s).style.opacity = 1;

      // ECG heartbeat line
      const ecg = $(".s1-ecg", s);
      let d = "M-20,540";
      [420, 960, 1500].forEach(c => {
        [[-80, 0], [-58, -12], [-40, 0], [-22, 0], [-12, 16], [0, -120], [14, 64], [26, 0], [52, 0], [72, -26], [96, 0]]
          .forEach(([dx, dy]) => d += ` L${c + dx},${540 + dy}`);
      });
      d += " L1940,540";
      this.ecgP = $(".ecg-path", ecg); this.ecgH = $(".ecg-head", ecg);
      this.ecgP.setAttribute("d", d); this.ecgH.setAttribute("d", d);
      this.ecgL = this.ecgP.getTotalLength();
      this.ecgP.style.strokeDasharray = this.ecgL;
      this.ecgH.style.strokeDasharray = `60 ${this.ecgL}`;

      // particles: 3-D cloud → real tree
      const R = rng(7);
      this.T = layoutTree(JSON.parse(JSON.stringify(D.tree)), { x0: 1110, x1: 1790, y0: 250, y1: 800 });
      const nodes = this.T.nodes, edges = nodes.filter(n => n.parent);
      const P = this.P = [];
      const NP = 340;
      for (let i = 0; i < NP; i++) {
        const u = R(), v = R(), th = u * 6.2832, ph = Math.acos(2 * v - 1), rad = lerp(220, 330, Math.pow(R(), .6));
        const p = { X: rad * Math.sin(ph) * Math.cos(th), Y: rad * Math.cos(ph) * .8, Z: rad * Math.sin(ph) * Math.sin(th), parent: i % 10, r: lerp(1.6, 3.2, R()), tw: R() };
        if (i < nodes.length * 5) {
          const n = nodes[i % nodes.length], a = R() * 6.28, rr = R() * (n.leaf ? 9 : 7);
          p.tx = n.x + Math.cos(a) * rr; p.ty = n.y + Math.sin(a) * rr;
          p.col = n.leaf ? lum(n.cls) : "#CFF8FF"; p.r = n.leaf ? lerp(2.2, 3.6, R()) : lerp(2, 3, R()); p.depth = n.depth;
        } else {
          const e = edges[(i * 7) % edges.length], k = R();
          const q = edgePt(e.parent, e, k);
          p.tx = q.x; p.ty = q.y; p.col = C.cyan; p.depth = e.depth - 1 + k; p.r = lerp(1.2, 2.2, R());
        }
        P.push(p);
      }
      // neighbour links in 3-D
      this.links = [];
      for (let i = 0; i < NP; i++) {
        let best = [[1e9, -1], [1e9, -1]];
        for (let j = 0; j < NP; j++) if (j !== i) {
          const a = P[i], b = P[j], dd = (a.X - b.X) ** 2 + (a.Y - b.Y) ** 2 + (a.Z - b.Z) ** 2;
          if (dd < best[1][0]) { best[1] = [dd, j]; best.sort((x, y) => x[0] - y[0]); }
        }
        best.forEach(([, j]) => j > i && this.links.push([i, j]));
      }
      this.edges = edges;
      this.M = { x: 1450, y: 520 };   // where the network forms

      s.addEventListener("click", e => {
        const a = e.target.closest("[data-act]"); if (!a) return;
        if (a.dataset.act === "begin") DIRECTOR.next();
        if (a.dataset.act === "replay") DIRECTOR.replay();
        if (a.dataset.act === "skip") DIRECTOR.skip();
        a.blur();
      });
    },
    origin() { return { x: this.T.root.x, y: this.T.root.y }; },
    camAt(t) {
      const zin = ease.inOut(seg(t, 3.4, 5.0)), zout = ease.inOut(seg(t, 8.5, 10));
      return 1 + .32 * zin * (1 - zout);
    },
    update(t) {
      const fx = this.fx; fx.clear();
      const g = fx.g;

      /* ECG heartbeat */
      const ek = ease.inOutSine(seg(t, .2, 2.6));
      this.ecgP.style.strokeDashoffset = (this.ecgL * (1 - ek)).toFixed(1);
      this.ecgH.style.strokeDashoffset = (-(this.ecgL * ek - 60)).toFixed(1);
      const ecgO = 1 - seg(t, 2.4, 3.4);
      this.ecgP.style.opacity = (.75 * ecgO).toFixed(3);
      this.ecgH.style.opacity = (ecgO * (ek < 1 ? 1 : 0)).toFixed(3);

      /* camera */
      const z = this.camAt(t), F = { x: 860, y: 560 };
      this.cam.style.transform = `translate(${F.x}px,${F.y}px) scale(${z.toFixed(4)}) translate(${-F.x}px,${-F.y}px)`;
      const cam = p => ({ x: F.x + (p.x - F.x) * z, y: F.y + (p.y - F.y) * z });

      /* hand: enters from the right, comes into focus, breathes, leaves */
      const hin = ease.out4(seg(t, 1.5, 4.4)), hout = ease.inOut(seg(t, 8.6, 10.0));
      const breathe = Math.sin(t * 1.3) * 2.2;
      const T = { x: 860, y: 560 };
      this.hand.set({
        x: T.x + 1150 * (1 - hin) + 1100 * hout, y: T.y + 30 * (1 - hin) + breathe + 260 * hout,
        r: -3 - 6 * (1 - hin) + Math.sin(t * .9) * .4 + 4 * hout, z: lerp(.94, 1, hin) - .05 * hout,
        o: clamp(hin * 3) * (1 - seg(t, 9.5, 10.0)), blur: 16 * (1 - ease.out(seg(t, 2.2, 4.6))) + 8 * hout
      });
      const pad = this.hand.pt(54, 219);       // underside of the fingertip

      /* lancet: approaches, a gentle tap, retracts */
      const th = 32 * Math.PI / 180, dir = { x: -Math.sin(th), y: Math.cos(th) };
      const app = ease.out(seg(t, 4.3, 5.15)), tap = Math.sin(Math.PI * seg(t, 5.15, 5.4)), back = ease.inOut(seg(t, 5.45, 6.4));
      const dist = lerp(320, 14, app) - 14 * tap + 360 * back;
      style(this.lancet, { x: pad.x + dir.x * dist, y: pad.y + dir.y * dist, r: 32, o: seg(t, 4.2, 4.6) * (1 - seg(t, 6.0, 6.4)) });

      /* droplet */
      const grow = ease.outBack(seg(t, 5.5, 6.9));
      const wick = seg(t, 7.35, 7.7) * (1 - seg(t, 7.9, 8.3));
      let dr = 13 * grow * (1 - .12 * wick);
      const det = ease.inOutSine(seg(t, 8.7, 10.3));
      const tip = cam(pad);
      const M = this.M;
      const dx = lerp(tip.x, M.x, ease.in(det) * .2 + det * .8), dy = lerp(tip.y, M.y - 18, det) - Math.sin(det * Math.PI) * 220;
      const glowK = seg(t, 9.0, 10.3);
      const toData = seg(t, 10.0, 10.5);
      if (t > 5.5 && toData < 1) fx.drop(dx, dy, dr * z * lerp(1, .9, det), lerp(.85, .05, det), 1 - toData, glowK);

      /* tap ripple */
      const rp = seg(t, 5.28, 6.0);
      if (rp > 0 && rp < 1) {
        g.strokeStyle = `rgba(200,245,255,${(.5 * (1 - rp)).toFixed(3)})`; g.lineWidth = 2;
        g.beginPath(); g.arc(tip.x, tip.y, 8 + 36 * ease.out(rp), 0, 6.283); g.stroke();
      }

      /* test strip: slides in, touches the drop, reads, leaves */
      const sin = ease.out(seg(t, 6.7, 7.4)), sout = ease.in(seg(t, 8.0, 8.7));
      const sp = { x: pad.x - 6, y: pad.y + 2 + 26 * grow };
      style(this.strip, { x: sp.x - 360 * (1 - sin) - 300 * sout, y: sp.y + 120 * (1 - sin) + 160 * sout, r: 188 - 20 * (1 - sin), o: seg(t, 6.6, 6.9) * (1 - seg(t, 8.4, 8.7)) });
      this.stripPad.setAttribute("fill", mix("#F3E6E3", "#E5574F", seg(t, 7.4, 7.9)));

      /* one particle → ten → hundreds → 3-D network → decision tree */
      const one = seg(t, 10.0, 10.5);
      if (one > 0 && seg(t, 10.5, 10.9) < 1) {
        const col = mix(C.bloodHi, C.cyan, one);
        fx.glow(M.x, M.y, 6 + 3 * Math.sin(one * Math.PI), col, 1);
      }
      const ten = ease.out(seg(t, 10.5, 11.1));
      const spawn = seg(t, 11.0, 12.0);
      const rot = (t - 11) * .32, tilt = .38, f = 900;
      const form = t >= 12.6;
      const P = this.P;
      const tens = [];
      for (let k = 0; k < 10; k++) {
        const a = k / 10 * 6.283 + .4;
        tens.push({ x: M.x + Math.cos(a) * 70 * ten, y: M.y + Math.sin(a) * 70 * ten });
      }
      if (ten > 0 && spawn < 1) tens.forEach(p => fx.glow(p.x, p.y, 4.2, C.cyan, 1 - spawn * .9));
      if (t >= 11.0) {
        const pos = this._pos || (this._pos = new Float32Array(P.length * 3));
        for (let i = 0; i < P.length; i++) {
          const p = P[i];
          const ca = Math.cos(rot), sa = Math.sin(rot), cb = Math.cos(tilt), sb = Math.sin(tilt);
          const x1 = p.X * ca + p.Z * sa, z1 = -p.X * sa + p.Z * ca;
          const y1 = p.Y * cb - z1 * sb, z2 = p.Y * sb + z1 * cb;
          const sc = f / (f + z2);
          let x = M.x + x1 * sc, y = M.y + y1 * sc;
          // spawn from the parent particle
          const sk = ease.out(clamp((spawn - (i % 37) / 37 * .45) / .55));
          const par = tens[p.parent];
          x = lerp(par.x, x, sk); y = lerp(par.y, y, sk);
          // organise into the tree, top levels first
          const mk = ease.inOut(clamp((t - 12.6 - p.depth * .22) / 1.3));
          x = lerp(x, p.tx, mk); y = lerp(y, p.ty, mk);
          pos[i * 3] = x; pos[i * 3 + 1] = y; pos[i * 3 + 2] = sc * (1 - mk) + mk;
        }
        // links fade while the tree forms
        const la = .22 * sk0(spawn) * (1 - seg(t, 12.8, 13.8));
        if (la > .01) {
          g.globalAlpha = la; g.strokeStyle = C.cyan; g.lineWidth = 1; g.beginPath();
          for (const [a, b] of this.links) { g.moveTo(pos[a * 3], pos[a * 3 + 1]); g.lineTo(pos[b * 3], pos[b * 3 + 1]); }
          g.stroke(); g.globalAlpha = 1;
        }
        // tree branches appear underneath
        const ta = .55 * seg(t, 13.2, 14.6);
        if (ta > 0) {
          g.globalAlpha = ta; g.strokeStyle = "rgba(91,227,240,.55)"; g.lineWidth = 1.4;
          for (const e of this.edges) {
            const a = e.parent, my = (a.y + e.y) / 2;
            g.beginPath(); g.moveTo(a.x, a.y); g.bezierCurveTo(a.x, my, e.x, my, e.x, e.y); g.stroke();
          }
          g.globalAlpha = 1;
        }
        for (let i = 0; i < P.length; i++) {
          const p = P[i], mk = clamp((t - 12.6 - p.depth * .22) / 1.3);
          const col = mk > .5 ? p.col : C.cyan;
          fx.glow(pos[i * 3], pos[i * 3 + 1], p.r * pos[i * 3 + 2], col, lerp(.55 + .45 * p.tw, 1, mk) * clamp(spawn * 3));
        }
      }

      /* title */
      rise(this.eyebrow, seg(t, 13.4, 14.2));
      rise(this.h1a, seg(t, 13.7, 14.6), 40);
      rise(this.h1b, seg(t, 14.0, 14.9), 40);
      rise(this.sub, seg(t, 14.5, 15.3));
      rise(this.acts, seg(t, 15.0, 15.7));
      rise(this.note, seg(t, 15.3, 16));
      this.skipB.style.opacity = (1 - seg(t, 14, 14.8)).toFixed(2);
      this.skipB.style.pointerEvents = t > 14.5 ? "none" : "auto";
      function sk0(v) { return clamp(v * 2); }
    }
  };

  /* ======================================================================
     2 · THREE CLASSES — three drops become three cards
     ====================================================================== */
  SCENES[1] = {
    duration: 3.4,
    init(api) {
      const s = this.s = api.slide;
      this.fx = api.fx($("canvas", s));
      this.head = $$(".head > *", s);
      this.wrap = $(".s2-cards", s);
      this.cards = $$(".ccard", s);
      this.pos = [{ x: 200, y: 470, ry: 5 }, { x: 740, y: 430, ry: 0 }, { x: 1280, y: 490, ry: -5 }];
      this.cards.forEach((c, i) => {
        c.style.setProperty("--ry", this.pos[i].ry + "deg");
        c.addEventListener("click", () => {
          const open = !c.classList.contains("open");
          this.cards.forEach(o => o.classList.remove("open"));
          c.classList.toggle("open", open);
          this.wrap.classList.toggle("has-open", open);
        });
      });
      // gentle parallax tilt
      s.addEventListener("pointermove", e => {
        if (!this.ready) return;
        const p = api.toStage(e);
        this.cards.forEach((c, i) => {
          const r = this.pos[i], cx = r.x + 220, cy = r.y + 200;
          const dx = clamp((p.x - cx) / 900, -1, 1), dy = clamp((p.y - cy) / 600, -1, 1);
          c.style.transform = `rotateY(${(r.ry + dx * 6).toFixed(2)}deg) rotateX(${(-dy * 5).toFixed(2)}deg)`;
        });
      });
    },
    enter() {
      this.ready = false;
      this.cards.forEach(c => c.classList.remove("open"));
      this.wrap.classList.remove("has-open");
    },
    update(t) {
      const fx = this.fx; fx.clear();
      this.head.forEach((h, i) => rise(h, seg(t, .05 + i * .12, .8 + i * .12)));
      this.cards.forEach((c, i) => {
        const P = this.pos[i], k = KEYS[i];
        const cx = P.x + 220, cy = P.y + 200;
        // falling drop
        const fall = ease.in(seg(t, .15 + i * .14, .85 + i * .14));
        const morph = ease.out4(seg(t, .85 + i * .14, 1.9 + i * .14));
        if (morph <= 0) fx.glow(cx, lerp(-40, cy, fall), 10, C[k], 1);
        const w = lerp(26, 440, morph), h = lerp(26, 400, ease.out(seg(t, .95 + i * .14, 2.1 + i * .14)));
        const st = c.style;
        st.left = (cx - w / 2) + "px"; st.top = (cy - h / 2) + "px";
        st.width = w + "px"; st.height = h + "px";
        st.borderRadius = lerp(13, 36, morph) + "px";
        st.opacity = morph > 0 ? 1 : 0;
        st.background = morph < 1 ? `linear-gradient(160deg, ${mix(C[k], "#FFFFFF", morph)}, ${mix(C[k], "#F7F4EF", morph)})` : "";
        st.padding = (44 * morph) + "px";
        if (!this.ready) st.transform = `rotateY(${(P.ry * morph).toFixed(2)}deg)`;
        const inner = seg(t, 1.7 + i * .14, 2.5 + i * .14);
        $$(".ccard-letter, .ccard-name, .ccard-hint", c).forEach(sp => sp.style.opacity = ease.out(inner).toFixed(3));
      });
    },
    done() {
      this.ready = true;
      this.cards.forEach(c => { c.style.height = ""; c.style.background = ""; });
    }
  };

  /* ======================================================================
     3 · HOW A DECISION TREE THINKS — illustrative, playable
     ====================================================================== */
  SCENES[2] = {
    duration: 6.2,
    init(api) {
      const s = this.s = api.slide;
      this.head = $$(".head > *", s);
      this.legend = $$(".s3-legend li", s);
      this.badge = $(".s3-badge", s);
      this.cap = $(".s3-caption", s);
      const T = this.svg = $(".s3-tree", s);
      const defs = svg("defs", {}, T);
      defs.innerHTML = `<filter id="s3glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="7"/></filter>
        <filter id="s3sh" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="14" stdDeviation="16" flood-color="#0A1531" flood-opacity=".16"/></filter>`;
      const n = this.nodes = {
        root: { x: 1290, y: 360, kind: "root", q: ["Blood sugar", "high?"] },
        dec: { x: 1010, y: 600, kind: "decision", q: ["Borderline", "high?"] },
        Y: { x: 1580, y: 600, kind: "leaf", cls: "Y", name: "Diabetic" },
        N: { x: 840, y: 850, kind: "leaf", cls: "N", name: "Non-diabetic" },
        P: { x: 1180, y: 850, kind: "leaf", cls: "P", name: "Pre-diabetic" }
      };
      n.dec.parent = n.root; n.Y.parent = n.root; n.N.parent = n.dec; n.P.parent = n.dec;
      n.dec.ans = "No"; n.Y.ans = "Yes"; n.N.ans = "No"; n.P.ans = "Yes";
      Object.entries(n).forEach(([id, v]) => v.id = id);
      const gE = svg("g", {}, T), gN = svg("g", {}, T);
      this.edges = [];
      ["dec", "Y", "N", "P"].forEach(id => {
        const c = n[id], p = c.parent;
        const r0 = p.kind === "root" ? 78 : 66;
        const d = `M${p.x},${p.y + r0} C${p.x},${(p.y + c.y) / 2 + 20} ${c.x},${(p.y + c.y) / 2 - 20} ${c.x},${c.y - (c.kind === "leaf" ? 52 : 66)}`;
        const g = svg("g", { class: "tedge-g" }, gE);
        const base = svg("path", { d, class: "tedge", fill: "none", stroke: "#0F1B33", "stroke-opacity": .22, "stroke-width": 4, "stroke-linecap": "round" }, g);
        const lit = svg("path", { d, fill: "none", stroke: C.N, "stroke-width": 7, "stroke-linecap": "round", opacity: 0 }, g);
        const hit = svg("path", { d, fill: "none", stroke: "transparent", "stroke-width": 44, style: "cursor:pointer" }, g);
        const L = base.getTotalLength();
        base.style.strokeDasharray = lit.style.strokeDasharray = L;
        const mid = base.getPointAtLength(L * .45);
        const lab = svg("text", { x: mid.x + (c.ans === "Yes" ? 22 : -22), y: mid.y, "text-anchor": c.ans === "Yes" ? "start" : "end", "font-family": "JetBrains Mono", "font-size": 22, "font-weight": 600, fill: "#44526B" }, g);
        lab.textContent = c.ans;
        hit.addEventListener("click", () => this.pick(id, true));
        this.edges.push({ id, base, lit, lab, L, c });
        c.edge = this.edges[this.edges.length - 1];
      });
      Object.values(n).forEach(v => {
        const g = v.g = svg("g", { class: "tnode", transform: `translate(${v.x},${v.y})` }, gN);
        v.inner = svg("g", {}, g);
        if (v.kind === "leaf") {
          v.halo = svg("rect", { x: -138, y: -62, width: 276, height: 124, rx: 34, fill: C[v.cls], opacity: 0, filter: "url(#s3glow)", class: "halo" }, v.inner);
          svg("rect", { x: -130, y: -52, width: 260, height: 104, rx: 26, fill: "#fff", stroke: C[v.cls], "stroke-width": 3, filter: "url(#s3sh)" }, v.inner);
          svg("rect", { x: -130, y: -52, width: 76, height: 104, rx: 26, fill: C[v.cls] }, v.inner);
          svg("rect", { x: -74, y: -52, width: 20, height: 104, fill: C[v.cls] }, v.inner);
          const L = svg("text", { x: -92, y: 15, "text-anchor": "middle", "font-family": "Fraunces", "font-style": "italic", "font-size": 46, fill: "#fff" }, v.inner); L.textContent = v.cls;
          const t2 = svg("text", { x: 38, y: 9, "text-anchor": "middle", "font-family": "Inter", "font-weight": 650, "font-size": 23, fill: "#0F1B33" }, v.inner); t2.textContent = v.name;
        } else {
          const R = v.kind === "root" ? 78 : 66;
          v.halo = svg("circle", { r: R + 16, fill: C.N, opacity: 0, filter: "url(#s3glow)", class: "halo" }, v.inner);
          svg("circle", { r: R, fill: v.kind === "root" ? "#0F1B33" : "#fff", stroke: "#0F1B33", "stroke-width": 3.5, filter: "url(#s3sh)" }, v.inner);
          v.q.forEach((line, i) => {
            const tx = svg("text", { y: (i - .5) * 28 + 9, "text-anchor": "middle", "font-family": "Inter", "font-weight": 620, "font-size": 23, fill: v.kind === "root" ? "#fff" : "#0F1B33" }, v.inner);
            tx.textContent = line;
          });
          v.ripple = svg("circle", { r: R, fill: "none", stroke: C.N, "stroke-width": 3, opacity: 0 }, g);
        }
        g.addEventListener("click", () => this.pick(v.id, true));
      });
      // the signal that travels along the selected path
      this.sig = svg("circle", { r: 10, fill: "#fff", stroke: C.N, "stroke-width": 4, opacity: 0, filter: "" }, T);
      this.hand = new Hand($(".s3-hand", s), { width: 640 });
      this.legend.forEach(li => li.addEventListener("click", () => this.pick({ root: "root", decision: "dec", leaf: "P" }[li.dataset.role], true)));
    },
    enter() { this.user = false; this.sel = undefined; this.pick(null); },
    caption(id) {
      return {
        root: "<b>Root node.</b> Every record starts here, with the first question.",
        dec: "Blood sugar high? <b>No</b> → a <b>decision node</b> asks a follow-up question.",
        Y: "Blood sugar high? <b>Yes</b> → leaf: <b class='cY'>Diabetic (Y)</b>",
        P: "High? <b>No</b> → Borderline? <b>Yes</b> → leaf: <b class='cP'>Pre-diabetic (P)</b>",
        N: "High? <b>No</b> → Borderline? <b>No</b> → leaf: <b class='cN'>Non-diabetic (N)</b>"
      }[id] || "Click any node or branch to follow a path.";
    },
    pick(id, user) {
      if (user) this.user = true;
      if (id === this.sel) return;
      this.sel = id;
      const n = this.nodes;
      const path = []; let c = id && n[id];
      while (c) { path.unshift(c); c = c.parent; }
      const on = new Set(path.map(p => p.id));
      const col = id && n[id].cls ? C[n[id].cls] : C.N;
      Object.values(n).forEach(v => {
        v.g.style.transition = "opacity .45s";
        v.g.style.opacity = !id || on.has(v.id) ? 1 : .32;
        v.halo.setAttribute("opacity", on.has(v.id) ? .35 : 0);
        v.halo.setAttribute("fill", col);
      });
      this.edges.forEach(e => {
        const lit = on.has(e.id);
        e.lit.setAttribute("stroke", col);
        e.lit.style.transition = "none";
        e.lit.setAttribute("opacity", lit ? 1 : 0);
        e.lit.style.strokeDashoffset = e.L;
        e.lab.setAttribute("fill", lit ? "#0F1B33" : "#7A8599");
      });
      this.path = path; this.sigStart = performance.now(); this.sigCol = col;
      this.cap.innerHTML = this.caption(id);
      this.legend.forEach(li => li.style.opacity = !id ? 1 : (li.dataset.role === n[id].kind ? 1 : .4));
    },
    tick(now) {
      if (!this.path || !this.path.length || this.sigStart == null) return;
      const per = 420, edges = this.path.slice(1);
      const k = (now - this.sigStart) / per;
      edges.forEach((v, i) => {
        const e = v.edge, q = clamp(k - i);
        e.lit.style.strokeDashoffset = (e.L * (1 - ease.inOut(q))).toFixed(1);
      });
      const i = Math.min(Math.floor(k), edges.length - 1);
      if (edges.length && k < edges.length + .5) {
        const e = edges[Math.max(0, i)].edge, q = ease.inOut(clamp(k - Math.max(0, i)));
        const p = e.base.getPointAtLength(e.L * q);
        this.sig.setAttribute("cx", p.x); this.sig.setAttribute("cy", p.y);
        this.sig.setAttribute("stroke", this.sigCol);
        this.sig.setAttribute("opacity", k < edges.length ? 1 : clamp(1 - (k - edges.length) * 2));
      } else this.sig.setAttribute("opacity", 0);
      // ripple on the selected node
      const tgt = this.path[this.path.length - 1];
      const rk = clamp((k - edges.length) / 1.2);
      Object.values(this.nodes).forEach(v => v.ripple && v.ripple.setAttribute("opacity", 0));
      if (tgt.ripple && rk > 0 && rk < 1) {
        tgt.ripple.setAttribute("opacity", (1 - rk) * .8); tgt.ripple.setAttribute("r", (tgt.kind === "root" ? 78 : 66) + 34 * ease.out(rk));
        tgt.ripple.setAttribute("stroke", this.sigCol);
      }
      if (k > edges.length + 2) this.sigStart = null;
    },
    update(t) {
      this.head.forEach((h, i) => rise(h, seg(t, .05 + i * .12, .8 + i * .12)));
      this.legend.forEach((l, i) => rise(l, seg(t, .5 + i * .18, 1.2 + i * .18)));
      rise(this.badge, seg(t, 1.2, 1.9), 10);
      rise(this.cap, seg(t, 2.0, 2.6), 10);
      const n = this.nodes;
      const pop = (v, a) => { const k = ease.outBack(seg(t, a, a + .55)); v.inner.setAttribute("transform", `scale(${Math.max(0.001, k).toFixed(3)})`); };
      pop(n.root, .2);
      const grow = (id, a) => { const e = n[id].edge; e.base.style.strokeDashoffset = (e.L * (1 - ease.inOut(seg(t, a, a + .6)))).toFixed(1); e.lab.style.opacity = seg(t, a + .4, a + .7); };
      grow("dec", .7); grow("Y", .8); pop(n.dec, 1.25); pop(n.Y, 1.35);
      grow("N", 1.55); grow("P", 1.65); pop(n.N, 2.1); pop(n.P, 2.2);
      // the hand reaches in from the top-right and taps the root node
      const hin = ease.out4(seg(t, 2.3, 3.6)), press = Math.sin(Math.PI * seg(t, 3.6, 3.95)), hout = ease.inOut(seg(t, 4.5, 5.9));
      const tip = { x: n.root.x + 58, y: n.root.y - 62 };
      const ang = -36, ux = Math.cos(ang * Math.PI / 180), uy = Math.sin(ang * Math.PI / 180);
      const off = 700 * (1 - hin) + 760 * hout - 10 * press;
      this.hand.set({ x: tip.x + ux * off, y: tip.y + uy * off, r: ang + Math.sin(t * 1.4) * .5, z: 1 - .03 * press, o: clamp(hin * 4) * (1 - seg(t, 5.4, 5.9)), blur: 6 * (1 - hin) + 4 * hout });
      if (!this.user) {
        const want = t >= 3.75 ? "Y" : null;
        if (want !== this.sel) this.pick(want);
      }
    }
  };

  /* ======================================================================
     4 · MEET THE DATASET — counters + a scanned constellation of features
     ====================================================================== */
  SCENES[3] = {
    duration: 4.8,
    init(api) {
      const s = this.s = api.slide;
      this.head = $$(".head > *", s);
      this.stats = $$(".stat, .s4-src", s);
      this.nums = $$(".stat-n", s);
      this.beam = $(".s4-beam", s);
      this.sum = $(".s4-sum", s);
      const F = this.field = $(".s4-field", s);
      const tip = el("div", "tip", s);
      const orbit = svg("svg", { width: 1060, height: 800, style: "position:absolute;inset:0;overflow:visible" }, F);
      const c = { x: 470, y: 400 };
      [180, 300].forEach(r => svg("circle", { cx: c.x, cy: c.y, r, fill: "none", stroke: "rgba(150,190,255,.16)", "stroke-width": 1.5, "stroke-dasharray": "3 9" }, orbit));
      const byId = Object.fromEntries(D.features.map(f => [f.id, f]));
      const place = [
        ["Gender", -90, 300, 62], ["BMI", -57, 300, 74], ["Age", -24, 300, 70],
        ["HbA1c", 9, 300, 66], ["TG", 42, 300, 66], ["VLDL", 75, 300, 60],
        ["Chol", 108, 300, 62], ["HDL", 141, 300, 56], ["LDL", 174, 300, 56],
        ["Urea", 207, 300, 58], ["Cr", 240, 300, 64]
      ];
      this.chips = [];
      const groupName = { sugar: "Blood sugar", body: "Body", lipid: "Lipids", kidney: "Kidney" };
      place.forEach(([id, ang, dist, r, cls]) => {
        const f = byId[id], a = ang * Math.PI / 180;
        const x = c.x + Math.cos(a) * dist, y = c.y + Math.sin(a) * dist;
        const ch = el("div", "fchip " + (cls || ""), F, `<div><span>${f.label}</span><small>${groupName[f.group]}</small></div>`);
        Object.assign(ch.style, { left: x + "px", top: y + "px", width: r * 2 + "px", height: r * 2 + "px" });
        if (id === "Cr" || id === "TG" || id === "Chol") ch.querySelector("span").style.fontSize = "18px";
        this.chips.push({ el: ch, x, y });
        svg("line", { x1: c.x, y1: c.y, x2: x, y2: y, stroke: "rgba(150,190,255,.12)", "stroke-width": 1.2 }, orbit);
        ch.addEventListener("pointerenter", () => {
          tip.innerHTML = `<span class="t-k" style="color:var(--cyan)">${f.label}</span><span class="t-v">${f.mean}</span>${id === "Gender" ? "" : "<span style='font-size:15px;opacity:.7'>overall average · </span>"}${f.note}`;
          tip.style.left = (780 + x) + "px"; tip.style.top = (150 + y - r + 6) + "px"; tip.classList.add("on");
        });
        ch.addEventListener("pointerleave", () => tip.classList.remove("on"));
      });
      // identifiers and the target complete the 14 columns
      [["ID", 60, 700, 58], ["No_Pation", 196, 752, 64]].forEach(([lab, x, y, r]) => {
        const ch = el("div", "fchip id", F, `<div><span style="font-size:${lab.length > 4 ? 15 : 19}px">${lab}</span><small>identifier</small></div>`);
        Object.assign(ch.style, { left: x + "px", top: y + "px", width: r * 2 + "px", height: r * 2 + "px" });
        this.chips.push({ el: ch, x, y });
      });
      // the classification target sits at the centre; its three classes beside it
      const tg = el("div", "fchip target", F, `<div><span style="font:500 46px/1 var(--serif)">CLASS</span><small>what we predict</small></div>`);
      Object.assign(tg.style, { left: c.x + "px", top: c.y + "px", width: "236px", height: "236px" });
      tg.addEventListener("pointerenter", () => {
        tip.innerHTML = `<span class="t-k" style="color:var(--cyan)">Target · CLASS</span><span class="t-v">3 classes</span>The model reads the 11 measurements and predicts N, P or Y.`;
        tip.style.left = (780 + c.x) + "px"; tip.style.top = (150 + c.y - 112) + "px"; tip.classList.add("on");
      });
      tg.addEventListener("pointerleave", () => tip.classList.remove("on"));
      D.classes.forEach((k, i) => {
        const x = 960, y = 400 + (i - 1) * 140;
        svg("path", { d: `M${c.x + 122},${c.y} C${c.x + 230},${c.y} 820,${y} ${x - 54},${y}`, stroke: "rgba(255,255,255,.3)", "stroke-width": 2, "stroke-dasharray": "2 8", fill: "none" }, orbit);
        const ch = el("div", "fchip cls", F, `<div><span style="font:italic 400 40px/1 var(--serif);color:var(--${k.key})">${k.key}</span><small>${k.name}</small></div>`);
        Object.assign(ch.style, { left: x + "px", top: y + "px", width: "108px", height: "108px", boxShadow: `0 0 0 2px var(--${k.key}) inset, 0 0 40px color-mix(in srgb, var(--${k.key}) 35%, transparent)` });
        ch.querySelector("small").style.fontSize = "10px";
        ch.addEventListener("pointerenter", () => {
          tip.innerHTML = `<span class="t-k" style="color:var(--${k.key})">${k.name} · ${k.key}</span><span class="t-v">${k.count} records</span>${k.pct}% of the dataset`;
          tip.style.left = (780 + x) + "px"; tip.style.top = (150 + y - 48) + "px"; tip.classList.add("on");
        });
        ch.addEventListener("pointerleave", () => tip.classList.remove("on"));
        this.chips.push({ el: ch, x, y });
      });
      this.chips.push({ el: tg, x: c.x, y: c.y });
      this.orbit = orbit;
    },
    update(t) {
      this.head.forEach((h, i) => rise(h, seg(t, .05 + i * .12, .8 + i * .12)));
      this.stats.forEach((st, i) => rise(st, seg(t, .3 + i * .15, 1 + i * .15)));
      this.nums.forEach((n, i) => {
        const to = +n.dataset.to, k = ease.out4(seg(t, .4 + i * .15, 2.2 + i * .15));
        n.textContent = Math.round(to * k).toLocaleString("en-US");
      });
      // scanning beam reveals each feature as it passes
      const bk = ease.inOutSine(seg(t, 1.0, 3.6));
      const bx = 700 + bk * 1180;
      this.beam.style.transform = `translateX(${(bx - 90).toFixed(1)}px)`;
      this.beam.style.opacity = (Math.min(seg(t, 1.0, 1.3), 1 - seg(t, 3.5, 3.9))).toFixed(3);
      this.orbit.style.opacity = ease.out(seg(t, 1.0, 2.6)).toFixed(3);
      this.chips.forEach(c => {
        const gx = 780 + c.x, k = ease.outBack(clamp((bx - gx + 40) / 200));
        c.el.style.opacity = clamp((bx - gx + 40) / 120).toFixed(3);
        c.el.style.transform = `translate(-50%,-50%) scale(${lerp(.55, 1, k).toFixed(3)})`;
        c.el.style.filter = k < 1 ? `blur(${(6 * (1 - clamp(k))).toFixed(1)}px)` : "";
      });
      rise(this.sum, seg(t, 3.8, 4.6));
    },
    done() { this.chips.forEach(c => c.el.style.transform = ""); }
  };

  /* ======================================================================
     5 · AN UNEXPECTED IMBALANCE — one drop becomes 1,000 records
     ====================================================================== */
  SCENES[4] = {
    duration: 8.8,
    init(api) {
      const s = this.s = api.slide;
      this.fx = api.fx($("canvas", s));
      this.head = $$(".head > *", s);
      this.q = $(".s5-q", s);
      this.tip = K.tooltip(s);
      this.hand = new Hand($(".s5-hand", s), { width: 900, mirror: true });
      const ch = this.chart = $(".s5-chart", s);
      const yB = this.yB = 880, per = this.per = 600 / 900;
      const bx = this.bx = { N: 1090, P: 1360, Y: 1630 }, bw = this.bw = 196;
      // grid + axis
      const grid = this.grid = svg("g", {}, ch);
      [0, 200, 400, 600, 800].forEach(v => {
        const y = yB - v * per;
        svg("line", { x1: 950, x2: 1770, y1: y, y2: y, stroke: "#0F1B33", "stroke-opacity": v ? .08 : .4, "stroke-width": v ? 1.5 : 2.5 }, grid);
        const tx = svg("text", { x: 930, y: y + 7, "text-anchor": "end", "font-family": "JetBrains Mono", "font-size": 19, fill: "#7A8599" }, grid);
        tx.textContent = v;
      });
      const yl = svg("text", { x: 930, y: yB - 840 * per - 40, "text-anchor": "end", "font-family": "JetBrains Mono", "font-size": 15, "letter-spacing": "2", fill: "#7A8599" }, grid);
      yl.textContent = "RECORDS";
      this.bars = {}; this.labels = [];
      D.classes.forEach(c => {
        const h = c.count * per, x = bx[c.key] - bw / 2;
        const g = svg("g", { class: "bar", "data-k": c.key }, ch);
        const r = svg("rect", { x, y: yB - h, width: bw, height: h, rx: 10, fill: C[c.key] }, g);
        const pct = svg("text", { x: bx[c.key], y: yB - h - 26, "text-anchor": "middle", "font-family": "Fraunces", "font-size": 56, fill: C[c.key] }, ch);
        pct.textContent = c.pct.toFixed(1) + "%";
        const lab = svg("text", { x: bx[c.key], y: yB + 46, "text-anchor": "middle", "font-family": "Inter", "font-size": 24, "font-weight": 650, fill: "#0F1B33" }, ch);
        lab.textContent = `${c.name} (${c.key})`;
        const cnt = svg("text", { x: bx[c.key], y: yB + 78, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-size": 19, fill: "#7A8599" }, ch);
        cnt.textContent = `${c.count} records`;
        this.bars[c.key] = { g, r, h };
        this.labels.push(pct, lab, cnt);
        g.addEventListener("pointerenter", () => this.tip.show(bx[c.key], yB - h - 90, `<span class="t-k" style="color:${C[c.key]}">${c.name} · ${c.key}</span><span class="t-v">${c.count} records</span>${c.pct}% of the dataset`));
        g.addEventListener("pointerleave", () => this.tip.hide());
      });
      // 1,000 particles — one per record
      const R = rng(11), P = this.P = [];
      const counts = { N: 0, P: 0, Y: 0 }, cols = 19;
      const centers = { N: { x: bx.N, y: 660, r: 52 }, P: { x: bx.P, y: 700, r: 38 }, Y: { x: bx.Y, y: 560, r: 150 } };
      for (let i = 0; i < 1000; i++) {
        const k = i < 103 ? "N" : i < 156 ? "P" : "Y";
        const j = counts[k]++;
        const row = Math.floor(j / cols), col = j % cols;
        const rowH = cols * per;
        const a = R() * 6.283, rr = Math.sqrt(R()) * centers[k].r;
        P.push({
          k, sx: lerp(860, 1840, R()), sy: lerp(180, 1000, R()),
          cx: centers[k].x + Math.cos(a) * rr, cy: centers[k].y + Math.sin(a) * rr,
          gx: bx[k] - bw / 2 + 6 + col * ((bw - 12) / (cols - 1)), gy: yB - (row + .5) * rowH,
          d: R(), row, r: lerp(2.6, 3.6, R())
        });
      }
      // order the burst so it radiates evenly
      this.q.querySelector(".qbtn").addEventListener("click", () => {
        const o = !this.q.classList.contains("open");
        this.q.classList.toggle("open", o); s.classList.toggle("miss", o);
      });
    },
    enter() { this.q.classList.remove("open"); this.s.classList.remove("miss"); },
    origin() { return { x: this.bx.Y, y: this.yB - 300 }; },
    update(t) {
      const fx = this.fx; fx.clear();
      this.head.forEach((h, i) => rise(h, seg(t, .05 + i * .12, .8 + i * .12)));
      // hand from the left carrying a drop
      const hin = ease.out4(seg(t, .2, 1.7)), hout = ease.inOut(seg(t, 2.7, 3.9));
      const H = { x: 640, y: 600 };
      this.hand.set({ x: H.x - 900 * (1 - hin) - 900 * hout, y: H.y + Math.sin(t * 1.3) * 2 + 20 * (1 - hin), r: 4 - 3 * hin - 6 * hout, z: 1, o: clamp(hin * 3) * (1 - seg(t, 3.5, 3.9)), blur: 8 * (1 - hin) + 6 * hout });
      const pad = this.hand.pt(54, 219);
      const pre = seg(t, 1.6, 2.3);                   // glow builds
      const burst = seg(t, 2.3, 2.45);
      if (t < 2.45) fx.drop(pad.x, pad.y, 15 * (1 + .25 * Math.sin(pre * Math.PI)), .75, 1 - burst, .4 + pre);
      // particles
      const spread = ease.out4(seg(t, 2.3, 3.6));
      const colK = seg(t, 2.9, 3.9);
      const fade = seg(t, 7.0, 7.7);
      const show = t >= 2.3 && fade < 1;
      const barK = ease.inOut(seg(t, 6.0, 7.1));
      if (show) for (const p of this.P) {
        const ck = ease.inOut(clamp((t - 3.6 - p.d * .5) / 1.0));
        const gk = ease.inOut(clamp((t - 4.8 - p.row * .022 - p.d * .25) / 1.0));
        let x = lerp(pad.x, p.sx, spread), y = lerp(pad.y + 30, p.sy, spread);
        x = lerp(x, p.cx, ck); y = lerp(y, p.cy, ck);
        x = lerp(x, p.gx, gk); y = lerp(y, p.gy, gk);
        const col = colK < 1 ? mix(C.blood, C[p.k], colK) : C[p.k];
        if (gk < 1) fx.glow(x, y, p.r * (1 - .3 * gk), col, .9);
        else fx.dot(x, y, 3.2, col, 1);
        if (gk >= 1 && barK > 0) fx.dot(x, y, 3.2, "#ffffff", .35 * barK);
      }
      // the chart solidifies under the particles
      this.grid.style.opacity = ease.out(seg(t, 4.6, 5.6)).toFixed(3);
      Object.entries(this.bars).forEach(([k, b], i) => {
        const gk = ease.out(seg(t, 6.0 + i * .12, 7.1 + i * .12));
        b.r.setAttribute("y", this.yB - b.h * gk); b.r.setAttribute("height", Math.max(0, b.h * gk));
        b.g.style.opacity = gk > 0 ? "" : 0;
      });
      this.labels.forEach((l, i) => l.style.opacity = ease.out(seg(t, 7.2 + (i % 3) * .1 + Math.floor(i / 3) * .12, 7.9 + Math.floor(i / 3) * .12)).toFixed(3));
      rise(this.q, seg(t, 7.9, 8.7));
    }
  };

  /* ======================================================================
     6 · THE SIGNAL — three test strips release their reading onto an axis
     ====================================================================== */
  SCENES[5] = {
    duration: 6.6,
    init(api) {
      const s = this.s = api.slide;
      this.head = $$(".head > *", s);
      this.take = $(".s6-take", s);
      this.tip = K.tooltip(s);
      const box = $(".s6-strips", s);
      const ch = $(".s6-chart", s);
      const x0 = this.x0 = 800, x1 = 1760, max = 16;
      const X = this.X = v => x0 + (x1 - x0) * v / max;
      const rows = this.rows = { N: 430, P: 555, Y: 680 };
      const axisY = this.axisY = 760;
      const defs = svg("defs", {}, ch);
      defs.innerHTML = `<filter id="s6g" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="6"/></filter>`;
      // axis + grid
      const ax = this.ax = svg("g", {}, ch);
      for (let v = 0; v <= 16; v += 2) {
        svg("line", { x1: X(v), x2: X(v), y1: 370, y2: axisY, stroke: "#9FB4D6", "stroke-opacity": .12, "stroke-width": 1.5 }, ax);
        const tx = svg("text", { x: X(v), y: axisY + 36, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-size": 19, fill: "#8EA0BE" }, ax);
        tx.textContent = v;
      }
      this.axLine = svg("line", { x1: x0, x2: x1, y1: axisY, y2: axisY, stroke: "#C7D3E6", "stroke-opacity": .55, "stroke-width": 2.5 }, ch);
      const al = svg("text", { x: x1, y: axisY + 72, "text-anchor": "end", "font-family": "JetBrains Mono", "font-size": 16, "letter-spacing": 2, fill: "#8EA0BE" }, ax);
      al.textContent = "HbA1c (%) · DOT = CLASS AVERAGE · LINE = MIN–MAX";
      // first split of our tree
      const sx = X(6.25);
      this.split = svg("g", {}, ch);
      svg("line", { x1: sx, x2: sx, y1: 360, y2: axisY, stroke: "#5BE3F0", "stroke-width": 2, "stroke-dasharray": "6 8" }, this.split);
      const st = svg("text", { x: sx + 14, y: 372, "font-family": "JetBrains Mono", "font-size": 17, fill: "#5BE3F0" }, this.split);
      st.textContent = "our tree's first question: HbA1c ≤ 6.25";
      // per-class marks
      this.marks = {};
      KEYS.forEach((k, i) => {
        const h = D.hba1c[k], y = rows[k], cl = C[k + "L"];
        const g = svg("g", {}, ch);
        const lab = svg("text", { x: x0 - 30, y: y + 8, "text-anchor": "end", "font-family": "Inter", "font-weight": 650, "font-size": 25, fill: cl }, ch);
        lab.textContent = D.classes[i].name;
        const range = svg("line", { x1: X(h.mean), x2: X(h.mean), y1: y, y2: y, stroke: cl, "stroke-width": 4, "stroke-linecap": "round", "stroke-opacity": .55 }, g);
        const capL = svg("line", { x1: X(h.min), x2: X(h.min), y1: y - 12, y2: y + 12, stroke: cl, "stroke-width": 3, opacity: 0 }, g);
        const capR = svg("line", { x1: X(h.max), x2: X(h.max), y1: y - 12, y2: y + 12, stroke: cl, "stroke-width": 3, opacity: 0 }, g);
        const halo = svg("circle", { cx: 0, cy: 0, r: 24, fill: cl, opacity: .5, filter: "url(#s6g)" }, ch);
        const dot = svg("circle", { cx: 0, cy: 0, r: 15, fill: cl, stroke: "#fff", "stroke-width": 3, class: "dot" }, ch);
        const val = svg("text", { x: X(h.mean), y: y - 30, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-weight": 600, "font-size": 26, fill: "#fff" }, ch);
        val.textContent = h.mean.toFixed(2);
        this.marks[k] = { range, capL, capR, halo, dot, val, lab, h, y };
        dot.addEventListener("pointerenter", () => this.tip.show(X(h.mean), y - 40, `<span class="t-k" style="color:${cl}">${D.classes[i].name}</span><span class="t-v">avg ${h.mean.toFixed(2)}</span>range ${h.min} – ${h.max} · ${D.classes[i].count} records`));
        dot.addEventListener("pointerleave", () => this.tip.hide());
      });
      // three test strips
      this.strips = KEYS.map((k, i) => {
        const e = el("div", "obj", box);
        prop(e, Art.stripSVG("#EDF1F5", `${k} · sample`), 46, 36);   // origin at the pad centre
        e._pad = $(".strip-pad", e);
        return e;
      });
    },
    origin() { return { x: this.X(8.88), y: this.rows.Y }; },
    update(t) {
      this.head.forEach((h, i) => rise(h, seg(t, .05 + i * .12, .8 + i * .12)));
      KEYS.forEach((k, i) => {
        const m = this.marks[k], y = m.y, cl = C[k + "L"];
        // strip floats in, its pad takes the class colour
        const a = .3 + i * .22;
        const fin = ease.out4(seg(t, a, a + 1.2)), fout = ease.in(seg(t, 2.3 + i * .1, 3.1 + i * .1));
        const px = 250 + 60 * i * 0, bob = Math.sin(t * 1.6 + i) * 3 * (1 - fout);
        style(this.strips[i], { x: px - 500 * (1 - fin) - 200 * fout, y: y + bob, r: lerp(-14, -2, fin), s: 1.1, o: clamp(fin * 2) * (1 - fout) });
        this.strips[i]._pad.setAttribute("fill", mix("#EDF1F5", cl, seg(t, 1.3 + i * .15, 1.9 + i * .15)));
        // the pad's colour lifts off as a data point and travels to the class average
        const lift = ease.inOut(seg(t, 2.0 + i * .15, 3.3 + i * .15));
        const sx = px + 46 * 1.1 - 46, ex = this.X(m.h.mean);
        const x = lerp(sx, ex, lift), yy = y - Math.sin(lift * Math.PI) * 90;
        const on = t >= 2.0 + i * .15;
        [m.dot, m.halo].forEach(c => { c.setAttribute("cx", x.toFixed(1)); c.setAttribute("cy", yy.toFixed(1)); c.style.opacity = on ? 1 : 0; });
        m.halo.style.opacity = on ? .5 + .3 * Math.sin(lift * Math.PI) : 0;
        m.dot.setAttribute("r", lerp(9, 15, lift));
        // range opens outwards from the average
        const rk = ease.out(seg(t, 3.6 + i * .12, 4.6 + i * .12));
        m.range.setAttribute("x1", lerp(ex, this.X(m.h.min), rk)); m.range.setAttribute("x2", lerp(ex, this.X(m.h.max), rk));
        m.range.style.opacity = rk > 0 ? 1 : 0;
        m.capL.setAttribute("opacity", seg(t, 4.4 + i * .12, 4.7 + i * .12)); m.capR.setAttribute("opacity", seg(t, 4.4 + i * .12, 4.7 + i * .12));
        m.val.style.opacity = ease.out(seg(t, 3.3 + i * .15, 3.9 + i * .15));
        m.lab.style.opacity = ease.out(seg(t, 3.0 + i * .12, 3.6 + i * .12));
      });
      const axk = ease.inOut(seg(t, 2.6, 3.6));
      this.ax.style.opacity = axk;
      this.axLine.setAttribute("x2", lerp(this.x0, 1760, axk));
      this.split.style.opacity = ease.out(seg(t, 4.9, 5.6));
      rise(this.take, seg(t, 5.6, 6.5));
    }
  };
})();
