/* Speaker notes — shown with N (drawer) or P (separate presenter window). */
window.NOTES = [
  { title: "The First Drop", points: [
    "Welcome. Our project: classifying diabetes status with a Decision Tree.",
    "The finger-prick is a metaphor: one small measurement becomes data, and data becomes decisions.",
    "Our dataset actually combines several lab measurements; HbA1c is a separate lab test.",
    "Press Begin (or →) to start." ] },
  { title: "Three Possible Outcomes", points: [
    "Every record has one target label, CLASS: N (non-diabetic), P (pre-diabetic) or Y (diabetic).",
    "Goal: predict the class from the medical measurements.",
    "Click each card to reveal its group size and average HbA1c." ] },
  { title: "How a Decision Tree Thinks", points: [
    "A Decision Tree asks one yes/no question at a time.",
    "Root node = first question, decision nodes = follow-up questions, leaf nodes = final class.",
    "This tree is a simplified illustration, not the trained model. The real one comes on slide 9.",
    "Trees are easy to explain and do not need scaled features." ] },
  { title: "Meet the Dataset", points: [
    "Diabetes Dataset from Mendeley Data: 1,000 records, 14 columns, 3 classes.",
    "14 columns = 11 measurements + 2 identifiers (ID, patient number) + the target.",
    "Our task: predict CLASS — N (non-diabetic), P (pre-diabetic) or Y (diabetic) — from the 11 measurements. Hover a class or feature for details.",
    "No missing values, but the labels needed cleaning." ] },
  { title: "An Unexpected Imbalance", points: [
    "Each dot is one record. Y = 844 (84.4%), N = 103 (10.3%), P = 53 (5.3%).",
    "Click the question: always predicting 'Diabetic' would already be 84.4% accurate.",
    "That is why we stratified the split and checked per-class metrics." ] },
  { title: "The Signal in the Data", points: [
    "Average HbA1c: N 4.56, P 6.00, Y 8.88.",
    "The N range (up to 5.6) and the P range (5.7–6.4) do not overlap.",
    "Lines show the min–max range. Y spans 2.0–16.0, so it overlaps the other classes.",
    "The dashed line is our tree's first split, HbA1c ≤ 6.25.",
    "BMI and Age are also higher in diabetic records. Cholesterol, HDL, LDL, Urea and Creatinine are similar across classes." ] },
  { title: "From Raw Data to Ready Data", points: [
    "Raw: 1,000 records. Labels were inconsistent ('f', 'Y ').",
    "Cleaning: fixed labels, dropped identifiers, removed 174 repeated profiles and 1 zero-cholesterol row, leaving 825.",
    "Encoding: Gender becomes 0/1 and the classes become 0/1/2, giving 11 features.",
    "Split: 80/20, stratified, random_state 42, so 660 train and 165 test.",
    "Outliers were kept because trees split on thresholds, not distances." ] },
  { title: "Baseline Model — Logistic Regression", points: [
    "Logistic Regression is our baseline: a simple reference point the tree has to beat.",
    "Features were standardised first (StandardScaler), then the model learns straight boundaries between N, P and Y (max_iter 1000).",
    "It is tested on the same 165 held-out records as the Decision Tree.",
    "The plot is schematic, to show the idea." ] },
  { title: "Cross-Validation — Finding the Best Depth", points: [
    "Depth = how many yes/no questions the tree may ask in a row.",
    "We tried depths 1–10 with 5-fold cross-validation on the 660 training records, scoring macro-F1.",
    "Depth 5 scored best (0.947). Shallower trees underfit; deeper trees scored lower (0.917–0.936).",
    "Hover a column for its score." ] },
  { title: "Decision Tree — Training with the Selected Depth (5)", points: [
    "We trained the final tree with max_depth = 5 on the 660 training records. This is that real tree.",
    "Root question: HbA1c ≤ 6.25. Most diabetic records (496) go right, then right again.",
    "Click a node, then Yes/No, to follow a record down to a leaf.",
    "Colour bars show the training records of each class at a node." ] },
  { title: "Model Comparison — Logistic Regression vs. Decision Tree", points: [
    "Test set: 165 unseen records.",
    "Accuracy: LR 93.9%, Tree 98.8%. Both look strong.",
    "Macro F1 weights each class equally: LR 74.2%, Tree 97.9%.",
    "Pre-diabetic recall: LR found 2 of 8, the Tree found 8 of 8." ] },
  { title: "Understanding the Mistakes", points: [
    "Each token is one test record. Rows = actual class, columns = predicted class.",
    "Tree: 163 correct, 2 wrong. Both errors are N records predicted as Y.",
    "Toggle to see the Logistic Regression matrix: 10 errors, mostly P records.",
    "Hover a cell for an explanation." ] },
  { title: "From Data to Decisions", points: [
    "Takeaways: the depth-5 tree got 163 of 165 test records right; it beat the baseline on every class (macro F1 97.9% vs 74.2%); with imbalanced data, per-class metrics matter more than accuracy.",
    "The tree is also explainable: every prediction is a short path of yes/no questions.",
    "Press → to play the closing.",
    "Limitations: one dataset, one split. Labels are closely tied to HbA1c. Not a diagnostic tool.",
    "Future work: feature importance, testing on an independent dataset.",
    "Thank you. Open for questions." ] }
];
