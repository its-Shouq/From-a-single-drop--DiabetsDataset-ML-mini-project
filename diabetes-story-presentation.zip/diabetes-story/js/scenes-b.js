/* ==========================================================================
   scenes-b.js — slides 7–12
   ========================================================================== */
(function () {
  const { clamp, lerp, seg, ease, rng, mix, C, KEYS, svg, el, $, $$, style, rise, Hand, layoutTree, edgeD, edgePt, pathTo, bez } = K;
  const D = window.DATA;
  const heads = (s) => $$(".head > *", s);
  const riseHead = (arr, t) => arr.forEach((h, i) => rise(h, seg(t, .05 + i * .12, .8 + i * .12)));

  /* ======================================================================
     7 · PIPELINE — 1 dot = 5 records flowing through the lab
     ====================================================================== */
  SCENES[6] = {
    duration: 7.2,
    init(api) {
      const s = this.s = api.slide;
      this.fx = api.fx($("canvas", s));
      this.head = heads(s);
      this.info = $(".s7-info", s); this.infoK = $(".s7-info-k", s); this.infoT = $(".s7-info-t", s);
      const Y0 = this.Y0 = 520;
      const xs = this.xs = [300, 720, 1140, 1560];
      const pipe = $(".s7-pipe", s);
      const defs = svg("defs", {}, pipe);
      defs.innerHTML = `<linearGradient id="s7glass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset=".5" stop-color="#E5F3F2" stop-opacity=".7"/><stop offset="1" stop-color="#CFE3E6" stop-opacity=".9"/></linearGradient>`;
      const tube = `M40,${Y0} L1680,${Y0}`;
      const fork = `M1680,${Y0} C1730,${Y0} 1740,430 1790,430 M1680,${Y0} C1730,${Y0} 1740,630 1790,630`;
      this.tubes = [];
      [[tube, 34], [fork, 22]].forEach(([d, w]) => {
        const a = svg("path", { d, fill: "none", stroke: "#0F1B33", "stroke-opacity": .14, "stroke-width": w + 4, "stroke-linecap": "round" }, pipe);
        const b = svg("path", { d, fill: "none", stroke: "url(#s7glass)", "stroke-width": w, "stroke-linecap": "round" }, pipe);
        const c = svg("path", { d, fill: "none", stroke: "#fff", "stroke-opacity": .9, "stroke-width": 3, "stroke-linecap": "round", transform: `translate(0,${-w / 4})` }, pipe);
        this.tubes.push(a, b, c);
      });
      this.tubes.forEach(p => { const L = p.getTotalLength(); p._L = L; p.style.strokeDasharray = L; });
      // reservoirs
      this.res = [["تدريب", 660, 430, 132], ["اختبار", 165, 630, 33]].map(([n, v, y, c]) => {
        const g = svg("g", { opacity: 0 }, pipe);
        svg("circle", { cx: 1790, cy: y, r: 52, fill: "url(#s7glass)", stroke: "#1FB5A5", "stroke-opacity": .5, "stroke-width": 2 }, g);
        const t = svg("text", { x: 1790, y: y, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-weight": 600, "font-size": 21, fill: "#0F1B33" }, g);
        t.textContent = `${n} · ${v}`;
        t.setAttribute("y", y + (n === "تدريب" ? -72 : 96));
        return { g, y, c };
      });
      this.minus = svg("text", { x: xs[1], y: 760, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-weight": 600, "font-size": 22, fill: C.blood, opacity: 0 }, pipe);
      this.minus.textContent = "حُذف 175 سجلًا";
      this.legend = svg("text", { x: 40, y: 600, "font-family": "JetBrains Mono", "font-size": 16, fill: "#7A8599", opacity: 0 }, pipe);
      this.legend.textContent = "النقطة = 5 سجلات";

      const ST = [
        ["البيانات الخام", "1,000", "سجل", "1,000 سجل و14 عمودًا، بلا قيم مفقودة، لكن التسميات غير متسقة: <bdi lang='en'>‘f’</bdi> بجانب <bdi lang='en'>‘F’</bdi>، و<bdi lang='en'>‘Y ’</bdi> بمسافة زائدة."],
        ["التنظيف", "825", "سجلًا فريدًا", "وحّدنا التسميات وحذفنا عمودي المعرّفات، ثم أزلنا <b>174</b> سجلًا طبيًا مكررًا وسجلًا <b>واحدًا</b> بقيمة كوليسترول صفرية غير منطقية."],
        ["الترميز", "11", "خاصية مُدخلة", "حوّلنا الجنس إلى عمود 0 / 1، والفئات N و P و Y إلى 0 و1 و2. وأبقينا القيم المتطرفة لأن الشجرة تعتمد على العتبات لا على المسافات."],
        ["التدريب / الاختبار", "80/20", "تقسيم طبقي", "<b>660</b> سجلًا للتدريب و<b>165</b> سجلًا للاختبار. التقسيم طبقي <bdi lang='en'>(stratified)</bdi> ليحافظ كل جزء على نسب الفئات."]
      ];
      const box = $(".s7-stations", s);
      this.st = ST.map(([name, num, unit, txt], i) => {
        const b = el("button", "station", box, `<span class="st-cap"><span><span class="st-num">${num}</span><span class="st-unit">${unit}</span></span></span><span class="st-name">${name}</span><span class="st-idx">الخطوة ${i + 1}</span>`);
        b.style.left = xs[i] + "px"; b.style.top = (Y0 - 115) + "px";
        b.addEventListener("click", () => this.show(i));
        b._txt = txt; b._name = name;
        return b;
      });
      // particles (200 = 1,000 records / 5)
      const R = rng(3), P = this.P = [];
      const clean = [];
      for (let i = 0; i < 19; i++) clean.push("N"); for (let i = 0; i < 8; i++) clean.push("P"); for (let i = 0; i < 138; i++) clean.push("Y");
      // stratified split: train N15 P6 Y111 / test N4 P2 Y27
      const testQuota = { N: 4, P: 2, Y: 27 }, trainSlots = [], testSlots = [];
      const removedIdx = new Set(); while (removedIdx.size < 35) removedIdx.add(Math.floor(R() * 200));
      let ci = 0;
      const order = clean.map((k, i) => ({ k, r: R() })).sort((a, b) => a.r - b.r).map(o => o.k);
      for (let i = 0; i < 200; i++) {
        const p = { i, launch: .9 + i * .014, wob: R() * 6.28, amp: lerp(4, 11, R()), sp: lerp(.92, 1.08, R()), gray: mix("#9AA6B8", "#C4CCD8", R()) };
        if (removedIdx.has(i)) p.removed = true;
        else {
          p.k = order[ci++];
          if (testQuota[p.k] > 0) { testQuota[p.k]--; p.test = true; testSlots.push(p); } else trainSlots.push(p);
        }
        P.push(p);
      }
      const pack = (arr, cy, rad) => {
        const n = arr.length, golden = 2.39996;
        arr.forEach((p, j) => { const rr = rad * Math.sqrt((j + .5) / n), a = j * golden; p.fx = 1790 + Math.cos(a) * rr; p.fy = cy + Math.sin(a) * rr; });
      };
      pack(trainSlots, 430, 40); pack(testSlots, 630, 30);
    },
    enter() { this.sel = -1; this.st.forEach(b => b.classList.remove("on")); this.info.style.opacity = 0; },
    show(i) {
      this.sel = i;
      this.st.forEach((b, j) => b.classList.toggle("on", j === i));
      this.infoK.textContent = `الخطوة ${i + 1} · ${this.st[i]._name}`;
      this.infoT.innerHTML = this.st[i]._txt;
      this.info.style.opacity = 1;
    },
    origin() { return { x: 1790, y: 630 }; },
    update(t) {
      const fx = this.fx; fx.clear();
      riseHead(this.head, t);
      const tk = ease.inOut(seg(t, .3, 1.5)), fk = ease.inOut(seg(t, 3.4, 4.2));
      this.tubes.forEach((p, i) => p.style.strokeDashoffset = p._L * (1 - (i < 3 ? tk : fk)));
      this.res.forEach(r => r.g.setAttribute("opacity", seg(t, 3.9, 4.4)));
      this.legend.setAttribute("opacity", seg(t, 1.2, 1.8));
      this.minus.setAttribute("opacity", seg(t, 2.4, 3.0));
      const trip = 2.7, xs = this.xs, Y0 = this.Y0;
      this.st.forEach((b, i) => {
        const arrive = .9 + (xs[i] - 40) / 1640 * trip;
        rise(b, seg(t, arrive - .45, arrive + .25), 30);
      });
      for (const p of this.P) {
        const u = (t - p.launch) * p.sp / trip;
        if (u <= 0) continue;
        let x = 40 + u * 1640, y = Y0 + Math.sin(u * 14 + p.wob) * p.amp, a = clamp(u * 8);
        let col = x < xs[1] ? p.gray : C[p.k] || p.gray, sq = x > xs[2];
        if (p.removed && x > xs[1]) {
          const d = (x - xs[1]) / 220;
          x = xs[1] + d * 60; y = Y0 + 160 * ease.in(clamp(d)) + Math.sin(p.wob) * 30 * d; a = 1 - clamp(d); col = C.blood; sq = false;
          if (a <= 0) continue;
        } else if (x > 1680) {
          const k = clamp((x - 1680) / 240);
          const ty = p.test ? 630 : 430;
          const e = ease.inOut(k);
          x = bez(1680, 1730, 1740, p.fx, e); y = bez(Y0, Y0, ty, p.fy, e);
          if (k >= 1) { x = p.fx; y = p.fy; }
        }
        if (sq) { const g = fx.g; g.globalAlpha = a; g.fillStyle = col; g.fillRect(x - 3, y - 3, 6, 6); g.globalAlpha = 1; }
        else fx.dot(x, y, 3.4, col, a);
      }
    },
    done() { if (this.sel < 0) { this.infoK.textContent = ""; this.infoT.innerHTML = "<span style='color:#7A8599'>اضغط على أي مرحلة لمعرفة ما قمنا به.</span>"; this.info.style.opacity = 1; } }
  };

  /** schematic scatter shared by slides 8 and 9 (not our data) */
  function schematicPlot(sv) {
    const R = rng(21), pts = [];
    const cl = { N: [140, 290, 60], P: [290, 205, 42], Y: [420, 120, 70] };
    [["N", 18], ["P", 10], ["Y", 30]].forEach(([k, n]) => {
      for (let i = 0; i < n; i++) {
        const [cx, cy, r] = cl[k], a = R() * 6.28, d = Math.sqrt(R()) * r;
        pts.push({ k, x: clamp(cx + Math.cos(a) * d * 1.2, 24, 536), y: clamp(cy + Math.sin(a) * d, 24, 376), d: R() });
      }
    });
    const regions = svg("g", {}, sv), lines = svg("g", {}, sv), dots = svg("g", {}, sv);
    const ds = pts.map(p => svg("circle", { cx: p.x, cy: p.y, r: 8, fill: C[p.k], stroke: "#fff", "stroke-width": 2.5 }, dots));
    return { sv, regions, lines, ds };
  }

  /* ======================================================================
     8 · TWO MODELS — straight lines vs. yes/no boxes (schematic)
     ====================================================================== */
  SCENES[7] = {
    duration: 4.6,
    init(api) {
      const s = this.s = api.slide;
      this.head = heads(s);
      this.panels = $$(".mpanel", s); this.facts = $$(".mfacts li", s); this.note = $(".s8-note", s);
      this.pl = $$(".mplot", s).map(schematicPlot);
      // LR: two straight boundaries
      const lr = this.pl[0];
      this.lrB = [
        { p: [215, 248], ang: 60, col: C.N, regCol: C.N, c: [140, 290] },
        { p: [355, 162], ang: 57, col: C.Y, regCol: C.Y, c: [420, 120] }
      ].map(b => ({ ...b, line: svg("line", { stroke: "#0F1B33", "stroke-width": 3, "stroke-linecap": "round" }, lr.lines), poly: svg("polygon", { fill: b.regCol, opacity: 0 }, lr.regions) }));
      this.lrMid = svg("polygon", { fill: C.P, opacity: 0 }, lr.regions);
    },
    /** clip the plot rectangle by the half-plane on one side of a line */
    clip(poly, px, py, ang, ref, keep = true) {
      const a = ang * Math.PI / 180, nx = -Math.sin(a), ny = Math.cos(a);
      const f0 = ([x, y]) => (x - px) * nx + (y - py) * ny;
      const sgn = (f0(ref) >= 0 ? 1 : -1) * (keep ? 1 : -1), f = p => f0(p) * sgn, out = [];
      for (let i = 0; i < poly.length; i++) {
        const A = poly[i], B = poly[(i + 1) % poly.length], fa = f(A), fb = f(B);
        if (fa >= 0) out.push(A);
        if ((fa >= 0) !== (fb >= 0)) { const k = fa / (fa - fb); out.push([A[0] + (B[0] - A[0]) * k, A[1] + (B[1] - A[1]) * k]); }
      }
      return out;
    },
    update(t) {
      riseHead(this.head, t);
      this.panels.forEach((p, i) => rise(p, seg(t, .3 + i * .15, 1.1 + i * .15), 30));
      this.pl.forEach(pl => pl.ds.forEach((d, i) => d.setAttribute("r", (8 * ease.outBack(seg(t, .8 + i * .012, 1.3 + i * .012))).toFixed(2))));
      // LR: lines swing into their fitted angle
      const lk = ease.inOut(seg(t, 1.6, 3.1)), rk = ease.out(seg(t, 2.8, 3.6));
      const rect = [[0, 0], [560, 0], [560, 400], [0, 400]], P = this.lrB.map((b, i) => {
        const ang = b.ang + (1 - lk) * (i ? -45 : 50), a = ang * Math.PI / 180, L = 700;
        const cx = b.p[0] + (1 - lk) * (i ? 40 : -40), cy = b.p[1];
        b.line.setAttribute("x1", cx - Math.cos(a) * L); b.line.setAttribute("y1", cy - Math.sin(a) * L);
        b.line.setAttribute("x2", cx + Math.cos(a) * L); b.line.setAttribute("y2", cy + Math.sin(a) * L);
        b.line.setAttribute("opacity", seg(t, 1.5, 1.8));
        return [cx, cy, ang, b.c];
      });
      const pts = arr => arr.map(p => p.map(v => v.toFixed(1)).join(",")).join(" ");
      this.lrB.forEach((b, i) => { b.poly.setAttribute("points", pts(this.clip(rect, ...P[i]))); b.poly.setAttribute("opacity", .17 * rk); });
      this.lrMid.setAttribute("points", pts(this.clip(this.clip(rect, ...P[0], false), ...P[1], false)));
      this.lrMid.setAttribute("opacity", .2 * rk);
      this.facts.forEach((li, i) => rise(li, seg(t, 1.2 + i * .35, 2.0 + i * .35), 24));
      rise(this.note, seg(t, 3.4, 4.1), 10);
    }
  };

  /* ======================================================================
     9 · CROSS-VALIDATION — finding the best depth (real CV scores)
     ====================================================================== */
  SCENES[8] = {
    duration: 5.2,
    init(api) {
      const s = this.s = api.slide;
      this.head = heads(s);
      this.panel = $(".mpanel", s); this.take = $(".cv-take", s); this.note = $(".cv-note", s);
      this.tip = K.tooltip(s);
      this.pl = schematicPlot($(".mplot", s));
      // DT: axis-aligned cuts
      const dt = this.pl;
      this.dtCuts = [
        { x1: 205, y1: 0, x2: 205, y2: 400, rect: [0, 0, 205, 400], col: C.N },
        { x1: 205, y1: 158, x2: 560, y2: 158, rect: [205, 0, 355, 158], col: C.Y },
        { x1: 362, y1: 158, x2: 362, y2: 400, rect: [362, 158, 198, 242], col: C.Y },
        { rect: [205, 158, 157, 242], col: C.P }
      ].map(c => ({ ...c, line: c.x1 != null ? svg("line", { stroke: "#0F1B33", "stroke-width": 3, "stroke-linecap": "round" }, dt.lines) : null, r: svg("rect", { x: c.rect[0], y: c.rect[1], width: c.rect[2], height: c.rect[3], fill: c.col, opacity: 0 }, dt.regions) }));
      this.qtags = [["HbA1c-like ≤ ?", 215, 30], ["≤ ?", 470, 148], ["≤ ?", 372, 390]].map(([tx, x, y]) => {
        const t = svg("text", { x, y, "font-family": "JetBrains Mono", "font-size": 15, fill: "#44526B", opacity: 0 }, dt.lines); t.textContent = tx; return t;
      });
      this.qtags[0].textContent = "السؤال 1"; this.qtags[1].textContent = "السؤال 2"; this.qtags[2].textContent = "السؤال 3";
      this.qtags[1].setAttribute("x", 214); this.qtags[2].setAttribute("x", 372); this.qtags[2].setAttribute("y", 388);
      // mean CV macro-F1 for depths 1–10, as columns on an honest 0–1 axis
      const ch = $(".cv-chart", s);
      const X0 = 880, step = 92, yB = this.yB = 800, H = this.H = 400;
      const defs = svg("defs", {}, ch);
      defs.innerHTML = `<filter id="cvGlow" x="-60%" y="-30%" width="220%" height="160%"><feGaussianBlur stdDeviation="12"/></filter>`;
      this.axis = svg("g", {}, ch);
      [0, .25, .5, .75, 1].forEach(v => {
        const y = yB - v * H;
        svg("line", { x1: 840, x2: 1790, y1: y, y2: y, stroke: "#0F1B33", "stroke-opacity": v ? .08 : .35, "stroke-width": v ? 1.5 : 2.5 }, this.axis);
        const tx = svg("text", { x: 822, y: y + 6, "text-anchor": "end", "font-family": "JetBrains Mono", "font-size": 17, fill: "#7A8599" }, this.axis); tx.textContent = v.toFixed(2);
      });
      const yl = svg("text", { x: 822, y: yB - H - 34, "text-anchor": "end", "font-family": "JetBrains Mono", "font-size": 14, "letter-spacing": 2, fill: "#7A8599" }, this.axis); yl.textContent = "متوسط macro-F1";
      const xl = svg("text", { x: X0 + step * 4.5, y: yB + 78, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-size": 14, "letter-spacing": 2, fill: "#7A8599" }, this.axis); xl.textContent = "أقصى عمق للشجرة";
      this.cols = D.depthCV.map((v, i) => {
        const x = X0 + i * step, best = i + 1 === D.chosenDepth, g = svg("g", { style: "cursor:pointer" }, ch);
        const glow = svg("rect", { x: x - 30, width: 60, rx: 18, fill: C.N, opacity: 0, filter: "url(#cvGlow)" }, g);
        const r = svg("rect", { x: x - 26, width: 52, rx: 14, fill: "#B9D3D6" }, g);
        const val = svg("text", { x, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-weight": 600, "font-size": 17, fill: "#44526B", opacity: 0 }, g); val.textContent = v.toFixed(3);
        const lab = svg("text", { x, y: yB + 36, "text-anchor": "middle", "font-family": "Inter", "font-weight": 650, "font-size": 22, fill: "#0F1B33" }, g); lab.textContent = i + 1;
        g.addEventListener("pointerenter", () => this.tip.show(x, yB - v * H - 46, `<span class="t-k" style="color:${C.N}">العمق ${i + 1}${best ? " · المختار" : ""}</span><span class="t-v">${v.toFixed(3)}</span>متوسط <bdi lang="en">macro-F1</bdi> عبر 5 طيّات`));
        g.addEventListener("pointerleave", () => this.tip.hide());
        return { x, v, best, r, glow, val, lab };
      });
      const b = this.cols[D.chosenDepth - 1];
      this.tag = svg("text", { x: b.x, y: yB - b.v * H - 52, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-weight": 600, "font-size": 15, "letter-spacing": 2, fill: C.N, opacity: 0 }, ch);
      this.tag.textContent = "الأفضل";
      this.scan = svg("rect", { y: yB - H - 20, width: 70, height: H + 20, rx: 20, fill: C.N, opacity: 0 }, ch);
    },
    update(t) {
      riseHead(this.head, t);
      rise(this.panel, seg(t, .3, 1.1), 30);
      this.pl.ds.forEach((d, i) => d.setAttribute("r", (8 * ease.outBack(seg(t, .8 + i * .012, 1.3 + i * .012))).toFixed(2)));
      // DT: one cut at a time
      this.dtCuts.forEach((c, i) => {
        const a = 1.4 + i * .55, k = ease.inOut(seg(t, a, a + .5));
        if (c.line) {
          c.line.setAttribute("x1", c.x1); c.line.setAttribute("y1", c.y1);
          c.line.setAttribute("x2", lerp(c.x1, c.x2, k)); c.line.setAttribute("y2", lerp(c.y1, c.y2, k));
          c.line.setAttribute("opacity", k > 0 ? 1 : 0);
          this.qtags[i].setAttribute("opacity", seg(t, a + .3, a + .6));
        }
        c.r.setAttribute("opacity", .18 * ease.out(seg(t, a + .35, a + .8)));
      });
      // columns rise one depth at a time, a scan compares them, the best one lights up
      this.axis.style.opacity = ease.out(seg(t, .7, 1.4));
      const sk = seg(t, 2.9, 3.9), scanX = lerp(this.cols[0].x, this.cols[9].x, ease.inOutSine(sk));
      this.scan.setAttribute("x", scanX - 35); this.scan.setAttribute("opacity", .1 * Math.sin(Math.PI * sk));
      const lit = ease.out(seg(t, 3.9, 4.5));
      this.cols.forEach((c, i) => {
        const k = ease.out(seg(t, 1.0 + i * .14, 1.8 + i * .14)), h = c.v * this.H * k;
        c.r.setAttribute("y", this.yB - h); c.r.setAttribute("height", Math.max(0, h));
        c.val.setAttribute("y", this.yB - c.v * this.H - 14);
        c.val.setAttribute("opacity", seg(t, 1.6 + i * .14, 2.0 + i * .14));
        const passed = clamp(1 - Math.abs(scanX - c.x) / 70) * (sk > 0 && sk < 1 ? 1 : 0);
        c.r.setAttribute("fill", c.best ? mix("#B9D3D6", "#1FB5A5", Math.max(lit, passed * .5)) : mix("#B9D3D6", "#8FBFC4", passed));
        if (c.best) { c.glow.setAttribute("y", this.yB - h - 4); c.glow.setAttribute("height", Math.max(0, h + 8)); c.glow.setAttribute("opacity", .45 * lit); c.val.setAttribute("fill", lit > .5 ? "#0F1B33" : "#44526B"); }
      });
      this.tag.setAttribute("opacity", lit);
      rise(this.take, seg(t, 4.3, 5.0), 16);
      rise(this.note, seg(t, 4.5, 5.2), 10);
    }
  };

  /* ======================================================================
     9 · INSIDE OUR DECISION TREE — the real model, explorable
     ====================================================================== */
  const FEAT_SHORT = { HbA1c: "السكر التراكمي", Cholesterol: "الكوليسترول", BMI: "مؤشر كتلة الجسم", Triglycerides: "الدهون الثلاثية", Creatinine: "الكرياتينين", Age: "العمر" };
  SCENES[9] = {
    duration: 3.6,
    init(api) {
      const s = this.s = api.slide;
      this.head = heads(s);
      this.panel = $(".s9-panel", s); this.foot = $(".s9-foot", s);
      this.pStep = $(".s9-step", s); this.pQ = $(".s9-q", s); this.pMix = $(".s9-mix", s); this.pMeta = $(".s9-meta", s);
      this.bYes = $("[data-go=L]", s); this.bNo = $("[data-go=R]", s);
      const T = this.T = layoutTree(JSON.parse(JSON.stringify(D.tree)), { x0: 170, x1: 1750, y0: 420, y1: 900 });
      const sv = $(".s9-tree", s);
      const defs = svg("defs", {}, sv);
      defs.innerHTML = `<filter id="s9g" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="8"/></filter>`;
      const gE = svg("g", {}, sv), gN = svg("g", {}, sv);
      this.sig = svg("circle", { r: 9, fill: "#fff", opacity: 0 }, sv);
      this.sigH = svg("circle", { r: 22, fill: C.cyan, opacity: 0, filter: "url(#s9g)" }, sv);
      T.nodes.forEach(n => {
        n.r = n.leaf ? 13 + 23 * Math.sqrt(n.total / 496) : 0;
        if (n.parent) {
          const p = n.parent;
          const y0 = p.y + 22, y1 = n.leaf ? n.y - n.r : n.y - 22;
          const my = (y0 + y1) / 2;
          const d = `M${p.x},${y0} C${p.x},${my} ${n.x},${my} ${n.x},${y1}`;
          const g = svg("g", {}, gE);
          n.eBase = svg("path", { d, fill: "none", stroke: "#8EA0BE", "stroke-opacity": .35, "stroke-width": 2.5 }, g);
          n.eLit = svg("path", { d, fill: "none", stroke: C.cyan, "stroke-width": 5, "stroke-linecap": "round", opacity: 0 }, g);
          n.L_ = n.eBase.getTotalLength();
          n.eBase.style.strokeDasharray = n.eLit.style.strokeDasharray = n.L_;
          if (p.depth === 0) {
            const mid = n.eBase.getPointAtLength(n.L_ * .5);
            n.eTag = svg("text", { x: mid.x + (n.side === "L" ? -16 : 16), y: mid.y - 10, "text-anchor": n.side === "L" ? "end" : "start", "font-family": "JetBrains Mono", "font-size": 17, fill: "#8EA0BE" }, g);
            n.eTag.textContent = n.side === "L" ? "نعم" : "لا";
          }
        }
        const g = n.g = svg("g", { class: "tnode", transform: `translate(${n.x},${n.y})`, style: "cursor:pointer" }, gN);
        n.inner = svg("g", {}, g);
        if (n.leaf) {
          const cl = C[n.cls + "L"];
          n.halo = svg("circle", { r: n.r + 14, fill: cl, opacity: 0, filter: "url(#s9g)" }, n.inner);
          n.body = svg("circle", { r: n.r, fill: cl, "fill-opacity": .22, stroke: cl, "stroke-width": 3 }, n.inner);
          const t1 = svg("text", { y: 7, "text-anchor": "middle", "font-family": "Fraunces", "font-style": "italic", "font-size": Math.max(20, n.r * .9), fill: "#fff" }, n.inner);
          t1.textContent = n.cls;
          const t2 = svg("text", { y: n.r + 24, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-size": 16, fill: "#C7D3E6" }, n.inner);
          t2.textContent = n.total;
        } else {
          const label = `${FEAT_SHORT[n.f]}\u200E ≤ ${n.t % 1 ? n.t : n.t.toFixed(1)}`;   // LRM: "≤ value" stays left-to-right
          const w = label.length * 9.6 + 40;
          n.halo = svg("rect", { x: -w / 2 - 10, y: -32, width: w + 20, height: 64, rx: 32, fill: C.cyan, opacity: 0, filter: "url(#s9g)" }, n.inner);
          n.body = svg("rect", { x: -w / 2, y: -22, width: w, height: 44, rx: 22, fill: "#12224A", stroke: n.depth === 0 ? "#fff" : "#5E77A8", "stroke-width": n.depth === 0 ? 3 : 2 }, n.inner);
          const tx = svg("text", { y: 6.5, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-weight": 600, "font-size": 17, fill: "#EAF1FB", "data-ltr": "" }, n.inner);
          tx.textContent = "\u2066" + label + "\u2069";          // keep "feature ≤ value" left-to-right, never mirrored
          tx.setAttribute("direction", "ltr");
          // tiny class-mix strip under each question
          let x = -w / 2 + 16; const bw = w - 32;
          n.v.forEach((c, i) => { const ww = bw * c / n.total; if (ww > 0) svg("rect", { x, y: 26, width: ww, height: 4, fill: C[KEYS[i] + "L"], rx: 2 }, n.inner); x += ww; });
        }
        g.addEventListener("click", () => this.select(n, true));
      });
      ["L", "R"].forEach(side => (side === "L" ? this.bYes : this.bNo).addEventListener("click", () => {
        const c = this.cur;
        if (!c) this.select(this.T.root, true);
        else if (c[side]) this.select(c[side], true);
      }));
      $("[data-go=reset]", s).addEventListener("click", () => this.select(null, true));
      this.mixEls = KEYS.map(k => { const i = el("i", "", this.pMix); i.style.background = C[k + "L"]; return i; });
    },
    enter() { this.select(null); },
    select(n, user) {
      this.cur = n;
      const path = n ? pathTo(n) : [];
      const on = new Set(path);
      this.T.nodes.forEach(m => {
        m.g.style.transition = "opacity .4s";
        m.g.style.opacity = !n || on.has(m) ? 1 : .38;
        m.halo.setAttribute("opacity", m === n ? .55 : on.has(m) ? .22 : 0);
        if (m.eLit) { m.eLit.setAttribute("opacity", on.has(m) ? 1 : 0); m.eLit.style.strokeDashoffset = m.L_; m.eLit.setAttribute("stroke", n && n.leaf ? C[n.cls + "L"] : C.cyan); }
        if (m.eBase && this._built) m.eBase.style.strokeOpacity = !n || on.has(m) ? .35 : .15;
      });
      this.sigPath = path; this.sigStart = performance.now();
      // panel
      const p = this.panel;
      p.classList.toggle("leaf", !!(n && n.leaf));
      if (!n) {
        this.pStep.textContent = "تتبّع سجلًا";
        this.pQ.innerHTML = "ابدأ من العقدة الجذرية";
        this.pMeta.innerHTML = "يبدأ كل سجل من الأعلى. اضغط على أي عقدة، أو اضغط <b>ابدأ</b>.";
        const r = this.T.root; this.mixEls.forEach((e, i) => e.style.flexGrow = r.v[i]);
        this.bYes.textContent = "ابدأ ↓"; this.bNo.style.display = "none";
        this.bYes.disabled = false;
        this.cur = null;
        return;
      }
      this.bYes.textContent = "نعم ↙"; this.bNo.style.display = "";
      this.mixEls.forEach((e, i) => e.style.flexGrow = n.v[i]);
      const counts = `<bdi dir="ltr">N <b>${n.v[0]}</b> · P <b>${n.v[1]}</b> · Y <b>${n.v[2]}</b></bdi>`;
      if (n.leaf) {
        const name = D.classes[KEYS.indexOf(n.cls)].name, maj = Math.max(...n.v);
        p.style.setProperty("--leafc", C[n.cls + "L"]);
        this.pStep.innerHTML = `العقدة النهائية · بعد ${K.rec(n.depth, ["سؤال", "أسئلة", "سؤالًا", "سؤالين"])}`;
        this.pQ.innerHTML = `التنبؤ: ${name} (${n.cls})`;
        this.pMeta.innerHTML = `${maj} من أصل ${K.rec(n.total)} للتدريب هنا من الفئة ${n.cls}.<br>${counts}`;
        this.bYes.disabled = this.bNo.disabled = true;
      } else {
        this.pStep.innerHTML = n.depth === 0 ? `العقدة الجذرية · السؤال 1` : `عقدة القرار · السؤال ${n.depth + 1}`;
        this.pQ.innerHTML = `هل <bdi dir="ltr">${FEAT_SHORT[n.f]}&lrm; <span class="op">≤</span> ${n.t}</bdi>؟`;
        this.pMeta.innerHTML = `يصل إلى هنا ${K.rec(n.total)} من بيانات التدريب.<br>${counts}`;
        this.bYes.disabled = this.bNo.disabled = false;
      }
    },
    tick(now) {
      if (this.sigStart == null) return;
      const path = this.sigPath, per = 380, k = (now - this.sigStart) / per;
      for (let i = 1; i < path.length; i++) {
        const m = path[i], q = ease.inOut(clamp(k - (i - 1)));
        m.eLit.style.strokeDashoffset = (m.L_ * (1 - q)).toFixed(1);
      }
      const n = path.length - 1;
      if (n >= 1 && k < n + .6) {
        const i = Math.min(Math.max(0, Math.floor(k)), n - 1), m = path[i + 1], q = ease.inOut(clamp(k - i));
        const pt = m.eBase.getPointAtLength(m.L_ * q);
        [this.sig, this.sigH].forEach(c => { c.setAttribute("cx", pt.x); c.setAttribute("cy", pt.y); });
        const o = k < n ? 1 : clamp(1 - (k - n) / .6);
        this.sig.setAttribute("opacity", o); this.sigH.setAttribute("opacity", o * .8);
        this.sigH.setAttribute("fill", path[n].leaf ? C[path[n].cls + "L"] : C.cyan);
      } else { this.sig.setAttribute("opacity", 0); this.sigH.setAttribute("opacity", 0); if (k > n + 1) this.sigStart = null; }
    },
    update(t) {
      riseHead(this.head, t);
      // a signal wave grows the tree from the root
      this.T.nodes.forEach(n => {
        const a = .35 + n.depth * .38;
        n.inner.setAttribute("transform", `scale(${Math.max(.001, ease.outBack(seg(t, a, a + .45))).toFixed(3)})`);
        if (n.eBase) n.eBase.style.strokeDashoffset = (n.L_ * (1 - ease.inOut(seg(t, a - .38, a)))).toFixed(1);
        if (n.eTag) n.eTag.style.opacity = seg(t, a, a + .4);
      });
      rise(this.panel, seg(t, 2.4, 3.1), 20);
      rise(this.foot, seg(t, 2.8, 3.5), 10);
    },
    done() { this._built = true; }
  };

  /* ======================================================================
     10 · RESULTS — two glass vessels, three honest metrics
     ====================================================================== */
  SCENES[10] = {
    duration: 4.2,
    init(api) {
      const s = this.s = api.slide;
      this.fx = api.fx($("canvas", s));
      this.head = heads(s);
      this.tabs = $(".s10-tabs", s); this.cap = $(".s10-cap", s);
      const sv = $(".s10-vessels", s);
      const top = this.top = 330, bot = this.bot = 860, w = 250;
      this.inTop = top + 18; this.inBot = bot - 16;
      const defs = svg("defs", {}, sv);
      defs.innerHTML = `
        <linearGradient id="s10glass" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity=".16"/><stop offset=".18" stop-color="#fff" stop-opacity=".04"/><stop offset=".8" stop-color="#fff" stop-opacity=".02"/><stop offset="1" stop-color="#fff" stop-opacity=".12"/></linearGradient>
        <linearGradient id="s10lr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#A9B9D6"/><stop offset="1" stop-color="#4B6496"/></linearGradient>
        <linearGradient id="s10dt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8DF4FF"/><stop offset="1" stop-color="#138C93"/></linearGradient>
        <filter id="s10b" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="14"/></filter>`;
      // scale
      const sc = svg("g", {}, sv);
      this.scale = sc;
      [0, 25, 50, 75, 100].forEach(v => {
        const y = this.lvl(v);
        svg("line", { x1: 450, x2: 1560, y1: y, y2: y, stroke: "#9FB4D6", "stroke-opacity": v ? .12 : .3, "stroke-width": 1.5, "stroke-dasharray": v ? "4 8" : "" }, sc);
        const tx = svg("text", { x: 430, y: y + 6, "text-anchor": "end", "font-family": "JetBrains Mono", "font-size": 18, fill: "#8EA0BE" }, sc);
        tx.textContent = v + "%";
      });
      this.V = [["lr", 640, "#s10lr", "Logistic Regression", "النموذج المرجعي"], ["dt", 1260, "#s10dt", "Decision Tree", "النموذج الرئيسي · العمق 5"]].map(([id, cx, grad, name, role]) => {
        const g = svg("g", {}, sv);
        const x0 = cx - w / 2, x1 = cx + w / 2, r = 46;
        const shape = `M${x0},${top} L${x0},${bot - r} Q${x0},${bot} ${x0 + r},${bot} L${x1 - r},${bot} Q${x1},${bot} ${x1},${bot - r} L${x1},${top}`;
        const clip = svg("clipPath", { id: "s10c" + id }, defs);
        svg("path", { d: `M${x0 + 8},${top} L${x0 + 8},${bot - r} Q${x0 + 8},${bot - 8} ${x0 + r},${bot - 8} L${x1 - r},${bot - 8} Q${x1 - 8},${bot - 8} ${x1 - 8},${bot - r} L${x1 - 8},${top} Z`, }, clip);
        const glow = svg("rect", { x: x0 + 20, y: bot - 60, width: w - 40, height: 60, fill: id === "dt" ? "#5BE3F0" : "#8EA0BE", opacity: .0, filter: "url(#s10b)" }, g);
        const liquid = svg("path", { fill: `url(${grad})`, "clip-path": `url(#s10c${id})`, opacity: .92 }, g);
        const surf = svg("path", { fill: "none", stroke: "#fff", "stroke-opacity": .7, "stroke-width": 2.5, "clip-path": `url(#s10c${id})` }, g);
        svg("path", { d: shape, fill: "url(#s10glass)", stroke: "#DCE8F8", "stroke-opacity": .55, "stroke-width": 3 }, g);
        svg("path", { d: `M${x0 + 22},${top + 30} L${x0 + 22},${bot - 70}`, stroke: "#fff", "stroke-opacity": .28, "stroke-width": 8, "stroke-linecap": "round" }, g);
        svg("ellipse", { cx, cy: top, rx: w / 2, ry: 10, fill: "none", stroke: "#DCE8F8", "stroke-opacity": .5, "stroke-width": 2.5 }, g);
        const val = svg("text", { x: x1 + 34, y: 0, "font-family": "Fraunces", "font-size": 74, fill: "#fff" }, g);
        const lead = svg("line", { x1: x1 + 4, x2: x1 + 26, stroke: "#fff", "stroke-opacity": .6, "stroke-width": 2 }, g);
        const nm = svg("text", { x: cx, y: bot + 52, "text-anchor": "middle", "font-family": "Inter", "font-weight": 650, "font-size": 30, fill: "#EAF1FB" }, g);
        nm.textContent = name;
        const rl = svg("text", { x: cx, y: bot + 86, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-size": 17, "letter-spacing": 2, fill: id === "dt" ? "#5BE3F0" : "#8EA0BE" }, g);
        rl.textContent = role.toUpperCase();
        return { id, cx, x0, x1, liquid, surf, val, lead, glow, nm, rl, level: 0, from: 0, to: 0 };
      });
      this.metric = "accuracy";
      $$(".tab", s).forEach(b => b.addEventListener("click", () => this.setMetric(b.dataset.m)));
      this.caps = {
        accuracy: 'يبدو النموذجان قويين — لكن <bdi dir="ltr">84%</bdi> من سجلات الاختبار لمصابين بالسكري.',
        macroF1: "عندما نمنح كل فئة <b>الوزن نفسه</b>، تظهر الفجوة الحقيقية.",
        pRecall: "حالات ما قبل السكري المكتشفة: <b>2 من 8</b> مقابل <b>8 من 8</b>."
      };
    },
    lvl(v) { return this.inBot - (this.inBot - this.inTop) * v / 100; },
    enter() { this.metric = "accuracy"; this.anim = null; $$(".tab", this.s).forEach(b => b.classList.toggle("on", b.dataset.m === "accuracy")); this.cap.innerHTML = this.caps.accuracy; },
    setMetric(m) {
      if (!this.ready) return;
      $$(".tab", this.s).forEach(b => b.classList.toggle("on", b.dataset.m === m));
      this.anim = { t0: performance.now(), from: this.V.map(v => v.level), to: this.V.map(v => D.models[v.id][m]) };
      this.metric = m;
      this.cap.style.opacity = 0;
      setTimeout(() => { this.cap.innerHTML = this.caps[m]; this.cap.style.opacity = 1; }, 300);
    },
    draw(v, level, wave, t, numK) {
      const y = this.lvl(level), x0 = v.x0, x1 = v.x1;
      let d = `M${x0},${y}`;
      for (let x = x0; x <= x1; x += 10) d += ` L${x},${(y + Math.sin(x * .045 + t * 3.2 + (v.id === "dt" ? 1 : 0)) * wave).toFixed(1)}`;
      v.surf.setAttribute("d", d);
      v.liquid.setAttribute("d", d + ` L${x1},${this.bot} L${x0},${this.bot} Z`);
      v.val.setAttribute("y", y + 25);
      v.lead.setAttribute("y1", y); v.lead.setAttribute("y2", y);
      v.val.textContent = level.toFixed(1) + "%";
      v.val.style.opacity = numK; v.lead.style.opacity = numK;
      v.val.style.filter = numK < 1 ? `blur(${(8 * (1 - numK)).toFixed(1)}px)` : "";
      v.glow.setAttribute("opacity", .5 * clamp(level / 100));
      v.level = level;
    },
    update(t) {
      const fx = this.fx; fx.clear();
      riseHead(this.head, t);
      this.ready = t >= this.duration;
      const R = this._R || (this._R = Array.from({ length: 140 }, (_, i) => rng(i + 1)()));
      this.V.forEach((v, j) => {
        const target = D.models[v.id].accuracy;
        const fk = ease.inOut(seg(t, .9 + j * .2, 3.0 + j * .2));
        const wave = 7 * (1 - seg(t, 2.6, 4.2)) * clamp(fk * 4);
        this.draw(v, target * fk, wave, t, ease.out(seg(t, 2.8 + j * .15, 3.6 + j * .15)));
        // a stream of data points pours into each vessel
        for (let i = 0; i < 70; i++) {
          const r = R[i + j * 70], st = .7 + j * .2 + r * 2.0, k = (t - st) / .7;
          if (k <= 0 || k >= 1) continue;
          const lvlY = this.lvl(target * fk);
          const x = v.cx + (R[(i * 7) % 140] - .5) * 120, y = lerp(170, lvlY, ease.in(k));
          fx.glow(x, y, 3.2, v.id === "dt" ? C.cyan : "#B9C7E2", .9 * (1 - k * .4));
        }
        v.nm.style.opacity = seg(t, .4 + j * .15, 1.0 + j * .15); v.rl.style.opacity = seg(t, .5 + j * .15, 1.1 + j * .15);
      });
      this.scale.style.opacity = seg(t, .3, 1.1);
      rise(this.tabs, seg(t, 3.2, 3.9), 10);
      this.cap.style.opacity = seg(t, 3.4, 4.0);
    },
    done() { this.ready = true; this.cap.style.opacity = 1; },
    tick(now) {
      if (!this.anim) return;
      const k = clamp((now - this.anim.t0) / 1300), e = ease.inOut(k);
      this.V.forEach((v, i) => this.draw(v, lerp(this.anim.from[i], this.anim.to[i], e), 6 * Math.sin(Math.PI * k), now / 1000, 1));
      if (k >= 1) this.anim = null;
    }
  };

  /* ======================================================================
     11 · CONFUSION MATRIX — 165 tokens fall through the tree into the grid
     ====================================================================== */
  SCENES[11] = {
    duration: 7,
    init(api) {
      const s = this.s = api.slide;
      this.fx = api.fx($("canvas", s));
      this.head = heads(s);
      this.side = $(".s11-side", s); this.ins = $(".s11-insight", s);
      this.tip = K.tooltip(s);
      const sv = $(".s11-svg", s);
      const T = this.T = layoutTree(JSON.parse(JSON.stringify(D.tree)), { x0: 170, x1: 800, y0: 340, y1: 640 });
      const gt = this.gTree = svg("g", {}, sv);
      T.nodes.forEach(n => {
        if (n.parent) svg("path", { d: edgeD(n.parent, n), fill: "none", stroke: "#0F1B33", "stroke-opacity": .2, "stroke-width": 2.5 }, gt);
      });
      T.nodes.forEach(n => svg("circle", { cx: n.x, cy: n.y, r: n.leaf ? 9 : 6, fill: n.leaf ? C[n.cls] : "#0F1B33", "fill-opacity": n.leaf ? .9 : .8 }, gt));
      const tl = svg("text", { x: T.root.x, y: 300, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-size": 16, "letter-spacing": 2, fill: "#7A8599" }, gt);
      tl.textContent = "165 سجلًا للاختبار ← شجرتنا";
      // matrix
      const X0 = this.X0 = 1100, Y0 = this.Y0 = 345, cs = this.cs = 190;
      const gm = this.gM = svg("g", {}, sv);
      const ph = svg("text", { x: X0 + cs * 1.5, y: Y0 - 64, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-size": 17, "letter-spacing": 3, fill: "#7A8599" }, gm); ph.textContent = "التنبؤ";
      const ah = svg("text", { x: X0 - 74, y: Y0 + cs * 1.5, "text-anchor": "middle", "font-family": "JetBrains Mono", "font-size": 17, "letter-spacing": 3, fill: "#7A8599", transform: `rotate(-90 ${X0 - 74} ${Y0 + cs * 1.5})` }, gm); ah.textContent = "الفئة الفعلية";
      this.cells = [];
      KEYS.forEach((k, i) => {
        const a = svg("text", { x: X0 + cs * i + cs / 2, y: Y0 - 22, "text-anchor": "middle", "font-family": "Fraunces", "font-style": "italic", "font-size": 34, fill: C[k] }, gm); a.textContent = k;
        const b = svg("text", { x: X0 - 26, y: Y0 + cs * i + cs / 2 + 12, "text-anchor": "middle", "font-family": "Fraunces", "font-style": "italic", "font-size": 34, fill: C[k] }, gm); b.textContent = k;
      });
      for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) {
        const g = svg("g", { class: "cell" }, gm);
        const rect = svg("rect", { x: X0 + c * cs + 5, y: Y0 + r * cs + 5, width: cs - 10, height: cs - 10, rx: 22, fill: r === c ? C[KEYS[r]] : "#0F1B33", "fill-opacity": r === c ? .1 : .035, stroke: "#0F1B33", "stroke-opacity": .1, "stroke-width": 2 }, g);
        const num = svg("text", { x: X0 + c * cs + 26, y: Y0 + r * cs + 54, "font-family": "Fraunces", "font-size": 40, fill: "#0F1B33", opacity: 0 }, g);
        const cell = { r, c, g, rect, num };
        this.cells.push(cell);
        g.addEventListener("pointerenter", () => this.hover(cell));
        g.addEventListener("pointerleave", () => this.tip.hide());
      }
      $(".s11-toggle", s).addEventListener("click", e => this.toggle(e.currentTarget));
      // tokens
      const R = rng(5), cm = D.models.dt.cm;
      const tokens = this.tokens = [];
      for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) for (let n = 0; n < cm[r][c]; n++) tokens.push({ tr: r, dt: c, d: R() });
      tokens.sort((a, b) => a.d - b.d);
      // push the two errors near the end, where everyone is watching
      const errs = tokens.filter(t => t.tr !== t.dt), rest = tokens.filter(t => t.tr === t.dt);
      rest.splice(rest.length - 20, 0, errs[0]); rest.splice(rest.length - 6, 0, errs[1]);
      this.tokens = rest;
      // LR predictions with the same true classes: [[17,0,2],[1,2,5],[1,1,136]]
      const lrCm = D.models.lr.cm;
      KEYS.forEach((_, r) => {
        const pool = this.tokens.filter(t => t.tr === r);
        let j = 0;
        // keep tokens in place where both models agree
        const want = lrCm[r].slice();
        pool.forEach(t => { if (want[t.dt] > 0) { t.lr = t.dt; want[t.dt]--; } });
        pool.forEach(t => { if (t.lr == null) { const c = want.findIndex(v => v > 0); t.lr = c; want[c]--; } });
      });
      // routes through the tree (into a leaf of the predicted class)
      const leaves = { N: [], P: [], Y: [] };
      T.leaves.forEach(l => leaves[l.cls].push(l));
      this.tokens.forEach((t, i) => {
        const pool = leaves[KEYS[t.dt]];
        let tot = pool.reduce((a, l) => a + l.total, 0), q = R() * tot, leaf = pool[0];
        for (const l of pool) { q -= l.total; if (q <= 0) { leaf = l; break; } }
        t.route = pathTo(leaf);
        t.start = .7 + i * .021;
      });
      this.slot("dt");
      this.mode = "dt";
    },
    /** assign every token a seat inside its matrix cell */
    slot(which) {
      const cs = this.cs, groups = {};
      this.tokens.forEach(t => { const key = t.tr + "," + t[which]; (groups[key] = groups[key] || []).push(t); });
      Object.entries(groups).forEach(([key, arr]) => {
        const [r, c] = key.split(",").map(Number);
        const x0 = this.X0 + c * cs + 22, y0 = this.Y0 + r * cs + 72, w = cs - 44, h = cs - 92;
        const cols = Math.max(1, Math.ceil(Math.sqrt(arr.length * w / h))), rows = Math.ceil(arr.length / cols);
        const sx = Math.min(w / cols, 22), sy = Math.min(h / Math.max(rows, 1), 22);
        arr.forEach((t, j) => {
          const cc = j % cols, rr = Math.floor(j / cols);
          t[which + "X"] = x0 + (cc + .5) * sx + (w - sx * cols) / 2;
          t[which + "Y"] = y0 + h - (rr + .5) * sy;
        });
        arr.forEach(t => t[which + "R"] = Math.min(6.2, sx * .36));
      });
    },
    hover(cell) {
      const cm = D.models[this.mode].cm, n = cm[cell.r][cell.c];
      const a = D.classes[cell.r], p = D.classes[cell.c];
      const ok = cell.r === cell.c;
      const html = `<span class="t-k" style="color:${ok ? C[a.key] : C.blood}">${ok ? "صحيح" : "خطأ"} · الفعلية ${a.key} ← المتوقعة ${p.key}</span><span class="t-v">${n ? K.rec(n) : "لا يوجد"}</span>` +
        (ok ? `سجلات «${a.name}» صُنّفت تصنيفًا صحيحًا.` : n ? `سجلات من فئة «${a.name}» صُنّفت خطأً على أنها «${p.name}».` : `لم يُخلط أي سجل من «${a.name}» مع «${p.name}».`);
      this.tip.show(this.X0 + cell.c * this.cs + this.cs / 2, this.Y0 + cell.r * this.cs + 8, html);
    },
    toggle(b) {
      if (!this.ready) return;
      const to = this.mode === "dt" ? "lr" : "dt";
      if (!this.tokens[0].lrX) this.slot("lr");
      this.anim = { t0: performance.now(), from: this.mode, to };
      this.mode = to;
      b.classList.toggle("on", to === "lr");
      b.innerHTML = to === "lr" ? 'العودة إلى <bdi lang="en">Decision Tree</bdi>' : 'قارن مع <bdi lang="en">Logistic Regression</bdi>';
      this.ins.innerHTML = to === "lr"
        ? "<b>155 من 165</b> تنبؤًا صحيحًا، و<b class='cErr'>10 أخطاء</b> — فاتته 6 من أصل 8 حالات ما قبل السكري."
        : "<b>163 من 165</b> تنبؤًا صحيحًا. أما <b class='cErr'>الخطآن</b> فهما سجلان من الفئة N صُنّفا على أنهما Y.";
      this.setNums(to, 1);
    },
    setNums(which, k) {
      const cm = D.models[which].cm;
      this.cells.forEach(c => {
        const n = cm[c.r][c.c];
        c.num.textContent = n;
        c.num.style.opacity = k * (n ? 1 : .35);
        const err = c.r !== c.c && n > 0;
        c.rect.setAttribute("stroke", err ? C.blood : "#0F1B33");
        c.rect.setAttribute("stroke-opacity", err ? .9 * k : .1);
        c.rect.setAttribute("stroke-width", err ? 3 : 2);
        c.num.setAttribute("fill", err ? C.blood : "#0F1B33");
      });
    },
    enter() {
      this.mode = "dt"; this.anim = null; this.ready = false;
      const b = $(".s11-toggle", this.s); b.classList.remove("on"); b.innerHTML = 'قارن مع <bdi lang="en">Logistic Regression</bdi>';
      this.ins.innerHTML = "<b>163 من 165</b> تنبؤًا صحيحًا. أما <b class='cErr'>الخطآن</b> فهما سجلان من الفئة N صُنّفا على أنهما Y.";
    },
    tokenPos(tk, t) {
      const u = (t - tk.start) / .95;
      if (u <= 0) return null;
      const route = tk.route, ns = route.length - 1;
      if (u < 1) {
        if (u < .15) { const k = u / .15; return { x: route[0].x, y: lerp(260, route[0].y, ease.out(k)), a: k }; }
        const v = (u - .15) / .85 * ns, i = Math.min(Math.floor(v), ns - 1);
        const p = edgePt(route[i], route[i + 1], ease.inOut(v - i));
        return { x: p.x, y: p.y, a: 1 };
      }
      const leaf = route[ns], f = ease.inOut(clamp((t - tk.start - .95) / .8));
      return { x: bez(leaf.x, leaf.x + 120, tk.dtX - 160, tk.dtX, f), y: bez(leaf.y, leaf.y + 140, tk.dtY - 40, tk.dtY, f) - Math.sin(f * Math.PI) * 120, a: 1, f };
    },
    update(t) {
      const fx = this.fx; fx.clear();
      riseHead(this.head, t);
      this.gTree.style.opacity = ease.out(seg(t, .2, .9));
      this.gM.style.opacity = ease.out(seg(t, .4, 1.1));
      this.ready = t >= this.duration;
      for (const tk of this.tokens) {
        const p = this.tokenPos(tk, t);
        if (!p) continue;
        const err = tk.tr !== tk.dt, col = C[KEYS[tk.tr]];
        const r = p.f != null ? lerp(5, tk.dtR, p.f) : 5;
        if (p.f == null || p.f < 1) fx.glow(p.x, p.y, r, col, p.a);
        else fx.dot(p.x, p.y, r, col, 1);
        if (err && p.f >= 1) this.ring(p.x, p.y, r, seg(t, 6.0, 6.5));
      }
      const nk = ease.out(seg(t, 5.6, 6.2));
      this.setNums("dt", nk);
      rise(this.side, seg(t, 6.1, 6.9), 20);
    },
    ring(x, y, r, k) {
      if (k <= 0) return;
      const g = this.fx.g;
      g.globalAlpha = k; g.strokeStyle = C.blood; g.lineWidth = 2.5;
      g.beginPath(); g.arc(x, y, r + 5, 0, 6.283); g.stroke();
      g.globalAlpha = .25 * k; g.beginPath(); g.arc(x, y, r + 11, 0, 6.283); g.stroke(); g.globalAlpha = 1;
    },
    tick(now) {
      if (!this.anim) return;
      const fx = this.fx; fx.clear();
      const A = this.anim, k = clamp((now - A.t0) / 1500);
      for (const [i, tk] of this.tokens.entries()) {
        const kk = ease.inOut(clamp((k - (i % 40) / 40 * .3) / .7));
        const fxp = tk[A.from + "X"], fyp = tk[A.from + "Y"], txp = tk[A.to + "X"], typ = tk[A.to + "Y"];
        const moved = fxp !== txp || fyp !== typ;
        const x = lerp(fxp, txp, kk), y = lerp(fyp, typ, kk) - (moved ? Math.sin(kk * Math.PI) * 60 : 0);
        const r = lerp(tk[A.from + "R"], tk[A.to + "R"], kk);
        fx.dot(x, y, r, C[KEYS[tk.tr]], 1);
        const errNow = tk.tr !== tk[A.to];
        if (errNow && kk >= 1) this.ring(x, y, r, 1);
      }
      if (k >= 1) this.anim = null;
    }
  };

  /* ======================================================================
     12 · CONCLUSION — insights, then the hand returns for the final tree
     ====================================================================== */
  SCENES[12] = {
    /* "Inside the Drop" — the drop on the fingertip glows, the camera pushes into it,
       travels through a microscopic bloodstream, the cells turn into data, the data
       grows into our real Decision Tree, a pulse runs through it, the branches flow
       into the blue World Diabetes Day circle, and the deck settles on the closing words. */
    duration: 18.0,
    holdAt: 3.0,
    init(api) {
      const s = this.s = api.slide;
      this.fx = api.fx($("canvas", s));
      this.head = $(".s12-head", s); this.headEls = heads(s);
      this.ins = $$(".s12-ins li", s); this.go = $(".s12-go", s);
      this.min = $(".s12-min", s); this.thanks = $(".s12-thanks", s); this.q = $(".s12-q", s);
      this.hand = new Hand($(".s12-hand", s), { width: 1150 });
      this.go.addEventListener("click", () => DIRECTOR.next());
      const T = this.T = layoutTree(JSON.parse(JSON.stringify(D.tree)), { x0: 620, x1: 1300, y0: 150, y1: 500 });
      this.C = { x: 960, y: 460 };               // centre of the data cloud
      this.RC = { x: 960, y: 470, r: 150 };     // the blue circle
      const R = rng(9), P = this.P = [];
      const edges = this.edges = T.nodes.filter(n => n.parent);
      for (let i = 0; i < 240; i++) {
        const p = { tone: i % 3 };              // 0 red→cyan · 1 cyan · 2 teal
        if (i < T.nodes.length * 6) {
          const n = T.nodes[i % T.nodes.length], a = R() * 6.28, rr = R() * (n.leaf ? 10 : 6);
          p.tx = n.x + Math.cos(a) * rr; p.ty = n.y + Math.sin(a) * rr; p.pd = n.depth; p.route = pathTo(n);
          p.col = n.leaf ? C[n.cls + "L"] : "#DFFBFF"; p.r = n.leaf ? lerp(2.2, 3.6, R()) : lerp(2, 3, R());
        } else {
          const e = edges[i % edges.length], k = lerp(.08, .92, R()), q = edgePt(e.parent, e, k);
          p.tx = q.x; p.ty = q.y; p.pd = e.depth - 1 + k; p.route = pathTo(e); p.col = C.cyan; p.r = lerp(1.2, 2.2, R());
        }
        const a = R() * 6.283, rr = lerp(30, 300, Math.sqrt(R()));
        p.cx = this.C.x + Math.cos(a) * rr * 1.5; p.cy = this.C.y + Math.sin(a) * rr * .75;
        const b = R() * 6.283, br = R() * 12;
        p.gx = T.root.x + Math.cos(b) * br; p.gy = T.root.y + Math.sin(b) * br;
        // its place on the blue circle
        p.ra = i / 240 * 6.2832 + (R() - .5) * .04; p.rr = this.RC.r + (R() - .5) * 26;
        p.ring = i % 3 === 0 ? C.cyan : i % 3 === 1 ? "#6FB8FF" : "#2E8FE0";
        p.d = R(); p.cell = i % 120; p.sw = R() * 6.28;
        P.push(p);
      }
      this.links = [];
      P.forEach((a, i) => {
        const near = P.map((b, j) => [(a.cx - b.cx) ** 2 + (a.cy - b.cy) ** 2, j]).filter(([, j]) => j !== i).sort((x, y) => x[0] - y[0]).slice(0, 2);
        near.forEach(([, j]) => j > i && this.links.push([i, j]));
      });
      // the microscopic bloodstream: biconcave red cells in 3-D around the camera path
      const CR = rng(31);
      this.cells = Array.from({ length: 120 }, () => ({
        th: CR() * 6.283, rad: lerp(.55, 3.4, Math.pow(CR(), .7)), z0: CR() * 14,
        rot: CR() * 6.283, spin: (CR() - .5) * 1.2, tumble: CR() * 6.283, tsp: lerp(.4, 1.3, CR()), d: CR()
      }));
      // 23 cells become the tree's nodes: pick cells that are on screen and in focus when the slow-down begins,
      // higher cells take higher levels so the motion flows naturally into the hierarchy
      const cand = this.cells.map((c, idx) => ({ idx, p: this.cellAt(c, 10.9) }))
        .filter(o => o.p.z > 1.4 && o.p.z < 7 && o.p.x > 260 && o.p.x < 1660 && o.p.y > 120 && o.p.y < 960)
        .sort((a, b) => a.p.z - b.p.z).slice(0, T.nodes.length).sort((a, b) => a.p.y - b.p.y);
      const order = T.nodes.slice().sort((a, b) => a.depth - b.depth || a.x - b.x);
      this.nodeCell = new Map();
      order.forEach((n, j) => { const o = cand[j % cand.length]; n.cell = this.cells[o.idx]; this.nodeCell.set(o.idx, n); n.leave = 10.9 + n.depth * .3; });
      this.specks = Array.from({ length: 90 }, () => ({ x: CR() * 2 - 1, y: CR() * 2 - 1, z0: CR() * 14, r: lerp(.6, 1.6, CR()) }));
      this.sprites = { red: this.cellSprites(["#5E0F1A", "#9A1F2B", "#D8433F", "#F2735F"]), cyan: this.cellSprites(["#0B4D57", "#138C93", "#3FE0CB", "#B8FBFF"]) };
    },
    /** a soft biconcave cell, pre-rendered sharp and at three blur levels (depth of field) */
    cellSprites([dim, mid, rim, hi]) {
      const S = 160, base = document.createElement("canvas");
      base.width = base.height = S;
      const g = base.getContext("2d"), c = S / 2, R = 56;
      const body = g.createRadialGradient(c, c, 0, c, c, R);
      body.addColorStop(0, dim); body.addColorStop(.38, mid); body.addColorStop(.74, rim); body.addColorStop(.9, mid); body.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = body; g.beginPath(); g.arc(c, c, R, 0, 6.2832); g.fill();
      const dip = g.createRadialGradient(c + 4, c + 6, 0, c, c, R * .5);            // the central dimple
      dip.addColorStop(0, "rgba(0,0,0,.28)"); dip.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = dip; g.beginPath(); g.arc(c, c, R * .5, 0, 6.2832); g.fill();
      g.globalAlpha = .55; g.strokeStyle = hi; g.lineWidth = 5; g.filter = "blur(2px)";   // rim light
      g.beginPath(); g.arc(c, c, R * .8, 3.5, 5.4); g.stroke();
      g.globalAlpha = .35; g.lineWidth = 3; g.beginPath(); g.arc(c, c, R * .36, .4, 1.9); g.stroke();
      g.filter = "none"; g.globalAlpha = 1;
      return [0, 3, 7, 13].map(b => {
        if (!b) return base;
        const cv = document.createElement("canvas"); cv.width = cv.height = S;
        const x = cv.getContext("2d"); x.filter = `blur(${b}px)`; x.drawImage(base, 0, 0);
        return cv;
      });
    },
    along(route, g) {
      if (g <= 0) return { x: route[0].x, y: route[0].y };
      const i = Math.min(Math.floor(g), route.length - 2), k = clamp(g - i);
      return edgePt(route[i], route[i + 1], ease.inOutSine(k));
    },
    /** screen position of cell i at time t (camera flies forward from t = 7.6) */
    cellAt(c, t) {
      const L = 14, f = 760, cz = this.cz(t);
      const z = (((c.z0 - cz) % L) + L) % L + .25;
      const sway = Math.sin(t * .5 + c.th) * .12;
      const wx = Math.cos(c.th) * c.rad + sway, wy = Math.sin(c.th) * c.rad * .8 + Math.cos(t * .4) * .15;
      return { x: 960 + wx / z * f, y: 540 + wy / z * f, z, s: .5 * f / z };
    },
    /** camera travel along the bloodstream: cruise, then a gentle slow-down from t = 10 */
    cz(t) {
      const d = Math.min(Math.max(t - 10, 0), 1.4);
      return 1.6 * clamp(t - 7.6, 0, 1) + 2.5 * clamp(t - 8.6, 0, 1.4) + 2.5 * d - 2.2 / 1.4 * d * d / 2 + .3 * Math.max(t - 11.4, 0);
    },
    /** final composition: the camera pulls back so the tree settles in the upper-middle of the frame */
    view(t) {
      const pull = ease.inOut(seg(t, 14.6, 16.2)), S = lerp(1.16, 1, pull), dy = lerp(46, 0, pull), cx = 960, cy = 325;
      return q => ({ x: cx + (q.x - cx) * S, y: cy + (q.y - cy) * S + dy });
    },
    update(t) {
      const fx = this.fx; fx.clear();
      const g = fx.g, k = fx.k;

      /* ---------------- phase A — insights (unchanged) ---------------- */
      const out = ease.inOut(seg(t, 3.1, 4.0));
      this.headEls.forEach((h, i) => {
        if (h.tagName !== "H2") return rise(h, seg(t, .05 + i * .12, .8 + i * .12));
        const q = ease.out(seg(t, .05 + i * .12, .8 + i * .12));          // slides in from the left
        h.style.opacity = q.toFixed(3);
        h.style.transform = q >= 1 ? "" : `translate3d(${(-(1 - q) * 60).toFixed(1)}px,0,0)`;
      });
      this.head.style.opacity = (1 - out).toFixed(3);
      this.ins.forEach((li, i) => {
        const kk = seg(t, .5 + i * .35, 1.4 + i * .35);
        rise(li, kk, 40);
        if (out > 0) { li.style.opacity = (1 - out).toFixed(3); li.style.transform = `translate3d(0,${(-40 * out).toFixed(1)}px,0)`; }
        const sw = seg(t, 1.0 + i * .35, 2.0 + i * .35);
        li.style.backgroundImage = sw > 0 && sw < 1 ? `linear-gradient(110deg, transparent ${sw * 140 - 40}%, rgba(91,227,240,.16) ${sw * 140 - 20}%, transparent ${sw * 140}%), linear-gradient(160deg, rgba(28,50,98,.55), rgba(12,24,54,.6))` : "";
      });
      rise(this.go, seg(t, 2.3, 2.9) * (1 - out), 10);
      this.go.style.pointerEvents = t < 3.1 ? "auto" : "none";
      this.min.style.opacity = (.9 * ease.inOut(seg(t, 3.3, 5.8))).toFixed(3);

      /* ---------------- scene 1 — the camera pushes into the drop ---------------- */
      const hin = ease.out4(seg(t, 3.6, 5.4));
      const T = { x: 1250, y: 470 };
      const base = {
        x: T.x + 1100 * (1 - hin), y: T.y + 30 * (1 - hin) + Math.sin(t * 1.3) * 2.2,
        r: -5 - 6 * (1 - hin) + Math.sin(t * .9) * .4, z: lerp(.94, 1, hin)
      };
      this.hand.set({ ...base, o: 1, blur: 0 });
      const pad = this.hand.pt(54, 219);
      const grow = ease.outBack(seg(t, 5.3, 6.4));
      const dropR = 15 * grow * (1 + .05 * Math.sin(seg(t, 6.0, 7.0) * Math.PI * 2));
      const A = { x: pad.x, y: pad.y + dropR * 1.68 };                  // centre of the drop's round body
      const push = seg(t, 6.6, 8.5), Z = Math.exp(ease.in(push) * Math.log(95)), pk = ease.inOut(seg(t, 6.6, 8.0));
      const cam = p => ({ x: lerp(A.x, 960, pk) + (p.x - A.x) * Z, y: lerp(A.y, 540, pk) + (p.y - A.y) * Z });
      const hp = cam(base);
      const handO = clamp(hin * 3) * (1 - seg(t, 7.6, 8.3));
      this.hand.set({
        x: hp.x, y: hp.y, r: base.r, z: base.z * Math.min(Z, 14),        // capped: it has left the frame by then
        o: handO, blur: 14 * (1 - ease.out(seg(t, 3.9, 5.6))) + 12 * ease.in(push)
      });
      this.hand.root.style.visibility = handO > .005 ? "visible" : "hidden";
      const glowK = seg(t, 5.9, 7.0);
      if (t > 5.3 && seg(t, 8.45, 8.8) < 1) {
        const dp = cam(pad);
        fx.drop(dp.x, dp.y, dropR * Z, .75, 1 - seg(t, 8.45, 8.8), glowK * (1 - push));
      }

      /* ---------------- scene 2 — the microscopic bloodstream ---------------- */
      const plasma = ease.inOut(seg(t, 8.15, 8.7)) * (1 - ease.inOut(seg(t, 11.8, 13.4)));
      const toData = seg(t, 10.2, 11.6);               // cells turn cyan / teal, keeping a red accent
      if (plasma > 0) {
        g.globalAlpha = plasma;
        const bg = g.createRadialGradient(760, 380, 40, 960, 540, 1200);
        bg.addColorStop(0, mix("#7A1A26", "#0E3C52", toData));
        bg.addColorStop(.45, mix("#3A0A14", "#0A2240", toData));
        bg.addColorStop(1, mix("#12030A", "#050B1C", toData));
        g.fillStyle = bg; g.fillRect(0, 0, 1920, 1080);
        const sh = g.createLinearGradient(300, 0, 1300, 1080);
        sh.addColorStop(0, "rgba(255,190,170,0)"); sh.addColorStop(.45, `rgba(255,190,170,${(.07 * (1 - toData)).toFixed(3)})`); sh.addColorStop(.55, "rgba(255,190,170,0)");
        g.fillStyle = sh; g.fillRect(0, 0, 1920, 1080);
        g.globalAlpha = 1;
        for (const sp of this.specks) {
          const z = (((sp.z0 - this.cz(t)) % 14) + 14) % 14 + .3;
          fx.dot(960 + sp.x * 3 / z * 760, 540 + sp.y * 2 / z * 760, sp.r * 3 / z, mix("#FFB3A6", "#9FF3FF", toData), .35 * plasma * clamp((14 - z) / 4));
        }
      }
      const V = this.view(t);
      const front = (t - 11.3) / .45;                  // tree growth front, in levels (root → leaves by 13.6 s)

      /* cells: drawn in depth order; node cells leave the flow and travel to their place in the tree */
      const drawCell = (x, y, size, rot, sy, lvl, ck, alpha) => {
        const sc = size / 112 * k, cs = Math.cos(rot) * sc, sn = Math.sin(rot) * sc;
        g.setTransform(cs, sn, -sn * sy, cs * sy, x * k, y * k);
        if (ck < 1) { g.globalAlpha = alpha * (1 - ck); g.drawImage(this.sprites.red[lvl], -80, -80); }
        if (ck > 0) { g.globalAlpha = alpha * ck; g.drawImage(this.sprites.cyan[lvl], -80, -80); g.globalAlpha = alpha * ck * .22; g.drawImage(this.sprites.red[lvl], -80, -80); }
      };
      const nodePos = n => {                           // current screen position + size of a node cell
        const c = n.cell, lk = ease.inOut(clamp((t - n.leave) / 1.15));
        const from = this.cellAt(c, Math.min(t, n.leave)), to = V(n);
        const arc = Math.sin(lk * Math.PI) * 40;
        return { x: lerp(from.x, to.x, lk), y: lerp(from.y, to.y, lk) - arc, s: lerp(from.s, 22, lk), lk, z: from.z };
      };
      if (t > 8.3) {
        const dis = c => clamp((t - 11.1 - c.d * .8) / .7);
        const list = this.cells.map((c, idx) => ({ c, idx, p: this.cellAt(c, t) })).sort((a, b) => b.p.z - a.p.z);
        for (const { c, idx, p } of list) {
          const node = this.nodeCell.get(idx);
          if (node && t >= node.leave) continue;       // drawn below as a travelling node
          const ck = ease.inOut(clamp((t - 10.2 - c.d * .6) / 1.0)) * (node ? 1 : .9);
          const fade = clamp((p.z - .25) / .6) * clamp((14 - p.z) / 4) * clamp((t - 8.3) / .8) * (node ? 1 : 1 - dis(c));
          if (fade <= .01 || p.s < 2) continue;
          const dof = Math.abs(p.z - 2.8), lvl = dof < .7 ? 0 : dof < 1.8 ? 1 : dof < 3.6 ? 2 : 3;
          drawCell(p.x, p.y, p.s, c.rot + c.spin * t, .32 + .68 * Math.abs(Math.cos(c.tumble + c.tsp * t)), lvl, ck, fade);
        }
        g.setTransform(k, 0, 0, k, 0, 0); g.globalAlpha = 1;
        if (plasma > 0) {
          const vg = g.createRadialGradient(960, 540, 420, 960, 540, 1150);
          vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, `rgba(3,6,16,${(.6 * plasma).toFixed(3)})`);
          g.fillStyle = vg; g.fillRect(0, 0, 1920, 1080);
        }
      }

      /* ---------------- scenes 3–4 — the cells connect and build the Decision Tree ---------------- */
      if (t >= 10.9) {
        const NP = new Map(this.T.nodes.map(n => [n, nodePos(n)]));
        const swell = Math.max(0, Math.sin(Math.PI * seg(t, 13.6, 14.6)));
        // connections: a fine luminous line links each node cell to its parent as soon as it leaves the flow
        for (const e of this.edges) {
          const a = NP.get(e.parent), b = NP.get(e);
          const q = clamp((t - e.leave) / 1.15);
          if (q <= 0) continue;
          const pa = { x: a.x, y: a.y }, pb = { x: lerp(a.x, b.x, ease.out(q)), y: lerp(a.y, b.y, ease.out(q)) };
          const settled = ease.inOut(clamp((t - e.leave - .6) / .8));
          [[5, .1 + .08 * swell], [1.6, .45 + .25 * settled + .2 * swell]].forEach(([w, al]) => {
            g.globalAlpha = al; g.strokeStyle = C.cyan; g.lineWidth = w; g.beginPath(); g.moveTo(pa.x, pa.y);
            for (let s2 = 1; s2 <= 18; s2++) {
              const u = s2 / 18, my = (pa.y + b.y) / 2;
              // straight while connecting, easing into the tree's curved branch once settled
              const cx = K.bez(pa.x, pa.x, pb.x, pb.x, u), cy = K.bez(pa.y, lerp(pa.y, my, settled), lerp(pb.y, my, settled), pb.y, u);
              g.lineTo(lerp(lerp(pa.x, pb.x, u), cx, settled), lerp(lerp(pa.y, pb.y, u), cy, settled) );
            }
            g.stroke();
          });
          g.globalAlpha = 1;
        }
        // particles released by the dissolving cells stream along the branches
        this.P.forEach(p => {
          const c = this.cells[p.cell], rel = 11.1 + c.d * .8;
          if (t < rel) return;
          const sk = ease.out(clamp((t - rel) / 1.2));
          const cp = this.cellAt(c, rel);
          const q = front >= p.pd ? { x: p.tx, y: p.ty } : this.along(p.route, Math.max(0, front));
          const tp = V(q);
          const x = lerp(cp.x + Math.cos(p.sw) * 16 * (1 - sk), tp.x, sk), y = lerp(cp.y + Math.sin(p.sw) * 16 * (1 - sk), tp.y, sk);
          const col = front >= p.pd ? p.col : p.tone === 0 ? mix(C.bloodHi, C.cyan, sk) : p.tone === 2 ? "#2DD4BF" : C.cyan;
          fx.glow(x, y, p.r, col, clamp((t - rel) / .3) * (.55 + .35 * sk));
        });
        // node cells: a glowing cell that shrinks into a luminous node
        const pf = (t - 13.9) / .22;                   // pulse of light from the root to the leaves
        for (const n of this.T.nodes) {
          const P = NP.get(n);
          if (t < n.leave) continue;
          const nodeCol = n.leaf ? C[n.cls + "L"] : "#DFFBFF";
          if (P.lk < 1) {
            drawCell(P.x, P.y, P.s, n.cell.rot + n.cell.spin * n.leave, 1, 0, 1, 1 - .7 * P.lk);
            g.setTransform(k, 0, 0, k, 0, 0); g.globalAlpha = 1;
          }
          const flash = Math.max(0, 1 - Math.abs(pf - n.depth) * 1.5);
          const shimmer = t > 15 ? .06 * Math.sin(t * 1.1 + n.x * .02) * (1 - seg(t, 16, 18)) : 0;
          fx.glow(P.x, P.y, (n.leaf ? 8 : 7) + 3 * swell + 5 * flash, nodeCol, Math.min(1, P.lk * 1.2) * (.8 + .2 * flash + shimmer));
          if (P.lk >= 1) fx.dot(P.x, P.y, n.leaf ? 3.2 : 2.6, "#FFFFFF", .85);
        }
        // the pulse travels along every branch
        if (pf > 0 && pf < 6.5) for (const e of this.edges) {
          const q = pf - (e.depth - 1);
          if (q > 0 && q < 1) { const pt = edgePt(V(e.parent), V(e), q); fx.glow(pt.x, pt.y, 7, "#E9FDFF", 1 - seg(t, 15.0, 15.4)); }
        }
      }

      /* ---------------- scene 7 — Thank You / Questions? beneath the tree ---------------- */
      rise(this.thanks, seg(t, 15.9, 17.0), 34);
      rise(this.q, seg(t, 16.5, 17.6), 24);
    }
  };
})();
