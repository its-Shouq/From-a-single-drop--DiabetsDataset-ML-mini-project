/* ==========================================================================
   core.js — tiny animation toolkit + shared visual helpers.
   Every scene is a pure function of time t (seconds): update(t) can be called
   with any t, which makes Skip / Replay exact and keeps motion deterministic.
   ========================================================================== */
(function () {
  const W = 1920, H = 1080;

  /* ---------------- math ---------------- */
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, k) => a + (b - a) * k;
  const seg = (t, a, b) => clamp((t - a) / (b - a));
  const ease = {
    lin: k => k,
    inOut: k => k < .5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2,
    out: k => 1 - Math.pow(1 - k, 3),
    out4: k => 1 - Math.pow(1 - k, 4),
    outExpo: k => k === 1 ? 1 : 1 - Math.pow(2, -10 * k),
    in: k => k * k * k,
    inOutSine: k => -(Math.cos(Math.PI * k) - 1) / 2,
    outBack: k => { const c = 1.30158, c3 = c + 1; return 1 + c3 * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); }
  };
  /** seeded PRNG (mulberry32) */
  function rng(seed) {
    let a = seed >>> 0;
    return () => {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  const bez = (p0, p1, p2, p3, k) => {
    const u = 1 - k;
    return u * u * u * p0 + 3 * u * u * k * p1 + 3 * u * k * k * p2 + k * k * k * p3;
  };
  function hexRgb(h) { const n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
  function mix(a, b, k) {
    const A = hexRgb(a), B = hexRgb(b);
    return `rgb(${A.map((v, i) => Math.round(lerp(v, B[i], k))).join(",")})`;
  }

  const C = {
    N: "#1AA99A", P: "#E8982E", Y: "#7363EE",
    NL: "#3FE0CB", PL: "#FFC266", YL: "#A69CFF",       // luminous variants for dark scenes
    blood: "#E5574F", bloodHi: "#FF8A7A", cyan: "#5BE3F0", ink: "#0F1B33", navy: "#0A1531", paper: "#F6F3EE"
  };
  const KEYS = ["N", "P", "Y"];

  /* ---------------- DOM ---------------- */
  const NS = "http://www.w3.org/2000/svg";
  function svg(tag, attrs = {}, parent) {
    const e = document.createElementNS(NS, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  }
  function el(tag, cls, parent, html) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    if (parent) parent.appendChild(e);
    return e;
  }
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  function style(e, o) {
    if (!e) return;
    if (o.x !== undefined || o.y !== undefined || o.s !== undefined || o.r !== undefined) {
      const sx = o.sx ?? o.s ?? 1, sy = o.sy ?? o.s ?? 1;
      e.style.transform = `translate3d(${(o.x || 0).toFixed(2)}px,${(o.y || 0).toFixed(2)}px,0) rotate(${(o.r || 0).toFixed(3)}deg) scale(${sx.toFixed(4)},${sy.toFixed(4)})`;
    }
    if (o.o !== undefined) e.style.opacity = o.o.toFixed(3);
    if (o.blur !== undefined) e.style.filter = o.blur > .05 ? `blur(${o.blur.toFixed(2)}px)` : "none";
  }
  /** fade+rise for text blocks. k in 0..1 */
  function rise(e, k, d = 26) {
    if (!e) return;
    const q = ease.out(clamp(k));
    e.style.opacity = q.toFixed(3);
    e.style.transform = q >= 1 ? "" : `translate3d(0,${((1 - q) * d).toFixed(1)}px,0)`;
  }

  /* ---------------- canvas FX ---------------- */
  const sprites = {};
  function sprite(color, soft = .55) {
    const key = color + soft;
    if (sprites[key]) return sprites[key];
    const s = 64, c = document.createElement("canvas");
    c.width = c.height = s;
    const g = c.getContext("2d");
    const [r, gg, b] = color.startsWith("#") ? hexRgb(color) : color.match(/\d+/g).map(Number);
    const grad = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    grad.addColorStop(0, `rgba(255,255,255,1)`);
    grad.addColorStop(.12, `rgba(${r},${gg},${b},1)`);
    grad.addColorStop(soft, `rgba(${r},${gg},${b},.28)`);
    grad.addColorStop(1, `rgba(${r},${gg},${b},0)`);
    g.fillStyle = grad; g.fillRect(0, 0, s, s);
    return (sprites[key] = c);
  }

  class FX {
    constructor(canvas) { this.c = canvas; this.g = canvas.getContext("2d"); this.k = 0; }
    resize(scale) {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const k = Math.max(.5, Math.min(scale * dpr, 2));
      if (k === this.k && this.c.width) return;
      this.k = k;
      this.c.width = Math.round(W * k); this.c.height = Math.round(H * k);
    }
    clear() { const g = this.g; g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, this.c.width, this.c.height); g.setTransform(this.k, 0, 0, this.k, 0, 0); }
    /** glowing particle */
    glow(x, y, r, color, a = 1) {
      if (a <= .004 || r <= .05) return;
      const g = this.g; g.globalAlpha = a;
      g.drawImage(sprite(color), x - r * 2.2, y - r * 2.2, r * 4.4, r * 4.4);
      g.globalAlpha = 1;
    }
    /** crisp dot */
    dot(x, y, r, color, a = 1) {
      if (a <= .004 || r <= .05) return;
      const g = this.g; g.globalAlpha = a; g.fillStyle = color;
      g.beginPath(); g.arc(x, y, r, 0, 6.2832); g.fill(); g.globalAlpha = 1;
    }
    line(x1, y1, x2, y2, color, a = 1, w = 1) {
      if (a <= .004) return;
      const g = this.g; g.globalAlpha = a; g.strokeStyle = color; g.lineWidth = w;
      g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); g.globalAlpha = 1;
    }
    /** a blood droplet hanging from (x, y). r = radius of the round part, neck 0..1 */
    drop(x, y, r, neck = .8, a = 1, glowK = 0) {
      if (r < .3 || a <= .004) return;
      const g = this.g;
      const cy = y + r * (1 + neck * .9);
      g.save(); g.globalAlpha = a;
      if (glowK > 0) {
        g.globalAlpha = a * glowK;
        g.drawImage(sprite(C.bloodHi, .5), x - r * 4, cy - r * 4, r * 8, r * 8);
        g.globalAlpha = a;
      }
      g.beginPath();
      g.moveTo(x, y);
      g.bezierCurveTo(x + r * .25, y + r * neck * .5, x + r, cy - r * .8, x + r, cy);
      g.arc(x, cy, r, 0, Math.PI, false);
      g.bezierCurveTo(x - r, cy - r * .8, x - r * .25, y + r * neck * .5, x, y);
      const grad = g.createRadialGradient(x - r * .35, cy - r * .4, r * .1, x, cy, r * 1.3);
      grad.addColorStop(0, "#FF9C8C"); grad.addColorStop(.45, "#E0473F"); grad.addColorStop(1, "#8E1E24");
      g.fillStyle = grad; g.fill();
      // specular
      g.globalAlpha = a * .85; g.fillStyle = "#fff";
      g.beginPath(); g.ellipse(x - r * .38, cy - r * .32, r * .2, r * .13, -.6, 0, 6.283); g.fill();
      g.globalAlpha = a * .25;
      g.beginPath(); g.ellipse(x + r * .35, cy + r * .45, r * .3, r * .1, -.5, 0, 6.283); g.fill();
      g.restore();
    }
  }

  /* ---------------- Hand controller ---------------- */
  class Hand {
    /** parent: .obj container. width: rendered px of the 1000-wide artwork */
    constructor(parent, { width = 1000, mirror = false, sleeve } = {}) {
      this.root = parent;
      this.k = width / HAND.w;
      this.mirror = mirror;
      parent.innerHTML = `<div class="hand-inner">${Art.handSVG({ sleeve })}</div>`;
      this.inner = parent.firstElementChild;
      const s = this.inner.style;
      s.position = "absolute";
      s.width = HAND.w + "px"; s.height = HAND.h + "px";
      s.left = (-HAND.tip.x) + "px"; s.top = (-HAND.tip.y) + "px";
      parent.style.transformOrigin = "0 0";
      this.inner.style.transformOrigin = `${HAND.tip.x}px ${HAND.tip.y}px`;
    }
    /** place fingertip at (x,y) in stage px; r degrees; extra scale z; blur px */
    set({ x = 0, y = 0, r = 0, z = 1, o = 1, blur = 0 }) {
      const k = this.k * z;
      this.root.style.transform = `translate3d(${x.toFixed(2)}px,${y.toFixed(2)}px,0) rotate(${r.toFixed(3)}deg) scale(${(this.mirror ? -k : k).toFixed(4)},${k.toFixed(4)})`;
      this.root.style.opacity = o.toFixed(3);
      this.root.style.filter = blur > .1 ? `blur(${blur.toFixed(1)}px)` : "none";
      this.x = x; this.y = y; this.r = r; this.z = z;
    }
    /** stage position of a point given in artwork coordinates */
    pt(ax, ay) {
      const k = this.k * this.z * (this.mirror ? -1 : 1), ky = this.k * this.z;
      const dx = (ax - HAND.tip.x) * k, dy = (ay - HAND.tip.y) * ky;
      const a = this.r * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
      return { x: this.x + dx * c - dy * s, y: this.y + dx * s + dy * c };
    }
  }

  /* ---------------- shared: tree layout (real trained tree) ---------------- */
  function layoutTree(root, box) {
    const nodes = [], leaves = [];
    let maxD = 0;
    (function walk(n, d, parent, side) {
      n.depth = d; n.parent = parent; n.side = side; n.leaf = !n.L;
      maxD = Math.max(maxD, d);
      nodes.push(n);
      if (n.L) { walk(n.L, d + 1, n, "L"); walk(n.R, d + 1, n, "R"); }
      else leaves.push(n);
    })(root, 0, null, null);
    leaves.forEach((l, i) => { l.x = lerp(box.x0, box.x1, leaves.length === 1 ? .5 : i / (leaves.length - 1)); });
    (function px(n) { if (n.L) { px(n.L); px(n.R); n.x = (n.L.x + n.R.x) / 2; } })(root);
    nodes.forEach(n => {
      n.y = lerp(box.y0, box.y1, n.depth / maxD);
      n.total = n.v[0] + n.v[1] + n.v[2];
      n.cls = KEYS[n.v.indexOf(Math.max(...n.v))];
    });
    return { nodes, leaves, maxD, root };
  }
  function pathTo(n) { const p = []; while (n) { p.unshift(n); n = n.parent; } return p; }
  /** a smooth branch curve between parent and child */
  function edgeD(a, b) {
    const my = (a.y + b.y) / 2;
    return `M${a.x},${a.y} C${a.x},${my} ${b.x},${my} ${b.x},${b.y}`;
  }
  function edgePt(a, b, k) {
    const my = (a.y + b.y) / 2;
    return { x: bez(a.x, a.x, b.x, b.x, k), y: bez(a.y, my, my, b.y, k) };
  }

  /* ---------------- tooltip helper ---------------- */
  function tooltip(slide) {
    const tip = $(".tip", slide);
    return {
      show(x, y, html) { tip.innerHTML = html; tip.style.left = x + "px"; tip.style.top = y + "px"; tip.classList.add("on"); },
      hide() { tip.classList.remove("on"); }
    };
  }

  /* ---------------- Arabic helpers ---------------- */
  /** "N سجل" with correct Arabic number agreement */
  function rec(n, word = ["سجل", "سجلات", "سجلًا", "سجلان"]) {
    const s = Number(n).toLocaleString("en-US"), m = n % 100;
    if (n === 1) return `${word[0]} واحد`;
    if (n === 2) return word[3];
    if (m >= 3 && m <= 10) return `${s} ${word[1]}`;
    if (m >= 11 && m <= 99) return `${s} ${word[2]}`;
    return `${s} ${word[0]}`;
  }
  const AR = /[\u0600-\u06FF]/;
  /** mark SVG labels that contain Arabic as RTL, keeping their visual anchor */
  function rtlSvg(root) {
    root.querySelectorAll("svg text").forEach(t => {
      if (!AR.test(t.textContent) || t.classList.contains("ar")) return;
      if (t.hasAttribute("data-ltr")) { t.classList.add("ar"); return; }
      const a = t.getAttribute("text-anchor") || "start";
      t.setAttribute("direction", "rtl");
      t.setAttribute("text-anchor", a === "start" ? "end" : a === "end" ? "start" : a);
      t.classList.add("ar");
    });
  }

  window.K = { rec, rtlSvg, W, H, clamp, lerp, seg, ease, rng, bez, mix, hexRgb, C, KEYS, svg, el, $, $$, style, rise, FX, Hand, layoutTree, pathTo, edgeD, edgePt, tooltip };
  window.SCENES = [];
})();
