/* ==========================================================================
   hand.js — layered SVG artwork: a pointing hand, a lancing pen, a test strip.
   Original vector artwork. The hand points LEFT; its fingertip pad sits at
   HAND.tip in the 1000×440 viewBox. Mirror with scaleX(-1) to point right.
   ========================================================================== */
(function () {
  let uid = 0;

  const HAND = {
    w: 1000, h: 440,
    tip: { x: 40, y: 196 },       // soft pad under the fingertip (prick site)
    nail: { x: 92, y: 150 }
  };

  function handSVG(opts = {}) {
    const p = "h" + (++uid);
    const sleeve = opts.sleeve || "#1B2A4A";
    return `
<svg class="hand-svg" viewBox="0 0 ${HAND.w} ${HAND.h}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <defs>
    <linearGradient id="${p}skin" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#F6D2B6"/>
      <stop offset=".38" stop-color="#E9B192"/>
      <stop offset=".78" stop-color="#CF8C6C"/>
      <stop offset="1" stop-color="#B0705A"/>
    </linearGradient>
    <linearGradient id="${p}skinD" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#DDA081"/>
      <stop offset=".6" stop-color="#BE7B5F"/>
      <stop offset="1" stop-color="#9A5E4A"/>
    </linearGradient>
    <linearGradient id="${p}thumb" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#F3C7A8"/>
      <stop offset=".5" stop-color="#E0A283"/>
      <stop offset="1" stop-color="#B77660"/>
    </linearGradient>
    <linearGradient id="${p}nail" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#FBE3DA"/>
      <stop offset=".55" stop-color="#EFC0B2"/>
      <stop offset="1" stop-color="#D99C8C"/>
    </linearGradient>
    <radialGradient id="${p}back" cx=".55" cy=".25" r=".6">
      <stop offset="0" stop-color="#FFE7D6" stop-opacity=".75"/>
      <stop offset="1" stop-color="#FFE7D6" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="${p}tipGlow" cx=".5" cy=".5" r=".5">
      <stop offset="0" stop-color="#FFB2A0" stop-opacity=".55"/>
      <stop offset="1" stop-color="#FFB2A0" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="${p}sleeve" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="${sleeve}" stop-opacity=".92"/>
      <stop offset=".5" stop-color="${sleeve}"/>
      <stop offset="1" stop-color="#0A1226"/>
    </linearGradient>
    <linearGradient id="${p}cuff" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="#FFFFFF" stop-opacity=".22"/>
      <stop offset=".25" stop-color="#FFFFFF" stop-opacity="0"/>
    </linearGradient>
    <linearGradient id="${p}rim" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="#9FF3FF" stop-opacity=".9"/>
      <stop offset=".45" stop-color="#9FF3FF" stop-opacity=".25"/>
      <stop offset="1" stop-color="#9FF3FF" stop-opacity="0"/>
    </linearGradient>
    <filter id="${p}soft" x="-10%" y="-10%" width="120%" height="120%"><feGaussianBlur stdDeviation="6"/></filter>
    <filter id="${p}softer" x="-20%" y="-50%" width="140%" height="200%"><feGaussianBlur stdDeviation="16"/></filter>
    <filter id="${p}crease" x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="1.1"/></filter>
    <clipPath id="${p}clipMid"><path d="M560,206 C470,204 400,214 386,250 C374,282 400,306 446,308 C500,310 560,300 610,290 L610,206 Z"/></clipPath>
    <filter id="${p}grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="7"/><feColorMatrix values="0 0 0 0 .35  0 0 0 0 .18  0 0 0 0 .12  0 0 0 1.6 -.55"/></filter>
    <clipPath id="${p}clipMain"><path d="${MAIN}"/></clipPath>
    <linearGradient id="${p}tmg" x1="0" x2="1"><stop offset=".62" stop-color="#fff"/><stop offset=".9" stop-color="#000"/></linearGradient>
    <mask id="${p}thumbMask" maskUnits="userSpaceOnUse" x="300" y="230" width="440" height="110"><rect x="300" y="230" width="440" height="110" fill="url(#${p}tmg)"/></mask>
    <clipPath id="${p}clipThumb"><path d="${THUMB}"/></clipPath>
  </defs>

  <!-- ground / contact shadow -->
  <ellipse class="hand-shadow" cx="620" cy="402" rx="560" ry="26" fill="#000" opacity=".28" filter="url(#${p}softer)"/>

  <g class="hand-body">
    <!-- curled ring finger (furthest back, peeks under the thumb) -->
    <path d="M640,292 C590,296 552,312 556,336 C560,356 596,362 640,356 C690,350 740,340 770,322 L760,290 Z" fill="url(#${p}skinD)"/>
    <!-- curled middle finger -->
    <path d="M560,206 C470,204 400,214 386,250 C374,282 400,306 446,308 C500,310 560,300 610,290 L610,206 Z" fill="url(#${p}skinD)"/>
    <path d="M380,214 L620,214" stroke="#4A2419" stroke-opacity=".5" stroke-width="14" filter="url(#${p}soft)" clip-path="url(#${p}clipMid)"/>
    <path d="M440,214 C414,222 398,236 394,256" fill="none" stroke="#F4C9AE" stroke-opacity=".6" stroke-width="3" filter="url(#${p}crease)"/>

    <!-- main silhouette: index finger + back of hand + wrist -->
    <path d="${MAIN}" fill="url(#${p}skin)"/>
    <g clip-path="url(#${p}clipMain)">
      <path d="${MAIN}" fill="url(#${p}back)"/>
      <!-- top highlight along finger and knuckles -->
      <path d="M34,166 C80,140 200,124 330,118 C400,114 460,108 520,102 C600,94 700,98 800,112" fill="none" stroke="#FFF0E4" stroke-opacity=".55" stroke-width="16" filter="url(#${p}soft)"/>
      <!-- knuckle (MCP) dome -->
      <ellipse cx="470" cy="128" rx="54" ry="26" fill="#FFE6D4" opacity=".35" filter="url(#${p}soft)"/>
      <!-- skin texture -->
      <rect x="0" y="80" width="830" height="290" filter="url(#${p}grain)" opacity=".10"/>
      <!-- underside / palm shade -->
      <path d="M20,214 C140,226 300,222 440,230 C520,300 620,340 820,334 L820,440 L20,440 Z" fill="#7D4434" opacity=".42" filter="url(#${p}soft)"/>
      <!-- pad warmth -->
      <ellipse cx="60" cy="200" rx="46" ry="24" fill="url(#${p}tipGlow)"/>
      <!-- shadow cast by the sleeve -->
      <path d="M770,90 L830,90 L830,360 L770,360 Z" fill="#3A1E16" opacity=".35" filter="url(#${p}soft)"/>
      <!-- knuckle creases (DIP, PIP) -->
      <path d="M150,138 C147,146 147,154 150,160" fill="none" stroke="#8C5240" stroke-opacity=".45" stroke-width="2" filter="url(#${p}crease)"/>
      <path d="M156,136 C153,144 153,152 156,158" fill="none" stroke="#8C5240" stroke-opacity=".25" stroke-width="1.6" filter="url(#${p}crease)"/>
      <path d="M282,126 C276,136 276,148 281,158" fill="none" stroke="#8C5240" stroke-opacity=".4" stroke-width="2.2" filter="url(#${p}crease)"/>
      <path d="M290,124 C284,134 284,146 289,156" fill="none" stroke="#8C5240" stroke-opacity=".22" stroke-width="1.6" filter="url(#${p}crease)"/>
      <path d="M296,126 C292,134 292,142 295,150" fill="none" stroke="#8C5240" stroke-opacity=".16" stroke-width="1.4" filter="url(#${p}crease)"/>
      <!-- underside flexion creases -->
      <path d="M136,216 C140,208 146,204 152,203" fill="none" stroke="#7D4434" stroke-opacity=".4" stroke-width="2" filter="url(#${p}crease)"/>
      <path d="M262,216 C268,208 276,205 284,204" fill="none" stroke="#7D4434" stroke-opacity=".4" stroke-width="2" filter="url(#${p}crease)"/>
    </g>
    <!-- fingernail -->
    <path d="M62,153 C76,142 104,136 132,135 C138,141 138,150 132,156 C114,162 88,164 70,163 C62,161 59,157 62,153 Z" fill="url(#${p}nail)"/>
    <path d="M132,135 C138,141 138,150 132,156" fill="none" stroke="#C98C78" stroke-width="2" stroke-opacity=".7"/>
    <path d="M72,149 C88,143 108,140 124,140" fill="none" stroke="#FFFFFF" stroke-opacity=".75" stroke-width="2.6" stroke-linecap="round"/>
    <path d="M64,156 C70,160 80,161 92,160" fill="none" stroke="#FFFFFF" stroke-opacity=".5" stroke-width="2" stroke-linecap="round"/>
    <!-- cyan rim light from the screen -->
    <path d="M24,192 C22,170 40,152 72,144 C140,128 260,120 400,114" fill="none" stroke="url(#${p}rim)" stroke-width="2.4" stroke-linecap="round"/>


    <!-- thumb (base fades into the palm) -->
    <g class="hand-thumb" mask="url(#${p}thumbMask)">
      <path d="${THUMB}" fill="url(#${p}thumb)"/>
      <g clip-path="url(#${p}clipThumb)">
        <path d="M300,238 C420,234 560,236 740,244" fill="none" stroke="#4A2419" stroke-opacity=".35" stroke-width="12" filter="url(#${p}soft)"/>
        <path d="M330,262 C420,250 540,246 700,252" fill="none" stroke="#FFF1E6" stroke-opacity=".55" stroke-width="12" filter="url(#${p}soft)"/>
        <path d="M320,312 C440,318 580,326 740,334 L740,360 L320,360 Z" fill="#6E3A2C" opacity=".5" filter="url(#${p}soft)"/>
        <path d="M486,252 C480,264 480,282 484,296" fill="none" stroke="#8C5240" stroke-opacity=".35" stroke-width="2" filter="url(#${p}crease)"/>
      </g>
      <path d="M370,266 C382,256 404,253 428,254 C432,262 432,272 427,279 C406,283 384,283 372,280 C365,276 365,270 370,266 Z" fill="url(#${p}nail)" opacity=".95"/>
      <path d="M378,264 C392,259 408,257 422,258" fill="none" stroke="#FFFFFF" stroke-opacity=".7" stroke-width="2" stroke-linecap="round"/>
    </g>

    <!-- sleeve -->
    <g class="hand-sleeve">
      <path d="M790,104 C830,96 900,92 1000,92 L2400,92 L2400,360 L1000,360 C920,360 850,358 800,350 C780,300 776,160 790,104 Z" fill="url(#${p}sleeve)"/>
      <path d="M790,104 C776,160 780,300 800,350 L830,352 C812,300 810,170 822,100 Z" fill="url(#${p}cuff)"/>
      <path d="M860,120 C870,190 868,270 872,340" fill="none" stroke="#000" stroke-opacity=".22" stroke-width="6" filter="url(#${p}soft)"/>
      <path d="M930,104 C936,180 934,280 940,352" fill="none" stroke="#FFF" stroke-opacity=".06" stroke-width="8" filter="url(#${p}soft)"/>
      <path d="M1040,100 C1050,180 1046,280 1052,356" fill="none" stroke="#000" stroke-opacity=".18" stroke-width="10" filter="url(#${p}soft)"/>
    </g>
  </g>
</svg>`;
  }

  /* Silhouettes (shared by fill and clip) */
  const MAIN = "M24,190 C24,166 46,148 80,142 C130,134 200,127 260,122 C340,116 400,112 450,110 C510,100 570,94 640,94 C700,94 760,104 820,110 L820,346 C760,350 700,352 650,348 C600,344 560,334 530,322 C500,296 470,252 440,226 C380,218 300,216 262,216 C190,218 120,222 66,221 C40,219 24,208 24,190 Z";
  const THUMB = "M730,250 C660,240 580,238 500,244 C470,248 430,250 392,256 C366,260 354,276 358,292 C362,308 384,316 420,316 C470,318 520,322 600,330 C650,334 700,334 730,326 Z";

  /* ---- Lancing pen (sterile, minimal, clinical) ---- */
  function lancetSVG() {
    const p = "l" + (++uid);
    return `
<svg class="lancet-svg" viewBox="0 0 120 520" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <defs>
    <linearGradient id="${p}body" x1="0" x2="1">
      <stop offset="0" stop-color="#C9D3DE"/><stop offset=".3" stop-color="#FFFFFF"/>
      <stop offset=".62" stop-color="#E6ECF2"/><stop offset="1" stop-color="#9DAABA"/>
    </linearGradient>
    <linearGradient id="${p}cap" x1="0" x2="1">
      <stop offset="0" stop-color="#0E7C86"/><stop offset=".35" stop-color="#3FD3D0"/><stop offset="1" stop-color="#0A5C66"/>
    </linearGradient>
    <linearGradient id="${p}tip" x1="0" x2="1">
      <stop offset="0" stop-color="#AFC0CF"/><stop offset=".4" stop-color="#F4F8FB"/><stop offset="1" stop-color="#8496A8"/>
    </linearGradient>
    <filter id="${p}sh" x="-50%" y="-10%" width="200%" height="120%"><feGaussianBlur stdDeviation="8"/></filter>
  </defs>
  <rect x="34" y="40" width="60" height="470" rx="30" fill="#000" opacity=".25" filter="url(#${p}sh)"/>
  <rect x="30" y="150" width="60" height="360" rx="30" fill="url(#${p}body)"/>
  <rect x="30" y="300" width="60" height="10" fill="#0E7C86" opacity=".5"/>
  <rect x="34" y="96" width="52" height="70" rx="14" fill="url(#${p}cap)"/>
  <path d="M38,30 L82,30 L86,100 L34,100 Z" fill="url(#${p}tip)"/>
  <rect x="50" y="10" width="20" height="24" rx="6" fill="url(#${p}tip)"/>
  <circle cx="60" cy="10" r="3" fill="#7B8B9C"/>
  <rect x="44" y="190" width="6" height="90" rx="3" fill="#fff" opacity=".9"/>
</svg>`;
  }

  /* ---- Glucose test strip ---- */
  function stripSVG(color = "#2CC2B2", label = "") {
    const p = "s" + (++uid);
    return `
<svg class="strip-svg" viewBox="0 0 360 80" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <defs>
    <linearGradient id="${p}g" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#E4EAF0"/>
    </linearGradient>
    <filter id="${p}sh" x="-10%" y="-60%" width="120%" height="220%"><feGaussianBlur stdDeviation="6"/></filter>
  </defs>
  <rect x="8" y="22" width="344" height="44" rx="8" fill="#000" opacity=".22" filter="url(#${p}sh)"/>
  <rect x="4" y="14" width="344" height="44" rx="8" fill="url(#${p}g)" stroke="#C7D2DC" stroke-width="1.5"/>
  <rect x="210" y="22" width="120" height="28" rx="4" fill="#E9EEF3"/>
  <path d="M224,36 H316" stroke="#B9C6D2" stroke-width="2" stroke-dasharray="4 5"/>
  <rect class="strip-pad" x="24" y="22" width="44" height="28" rx="6" fill="${color}"/>
  <rect x="24" y="22" width="44" height="10" rx="5" fill="#fff" opacity=".35"/>
  ${label ? `<text x="140" y="42" font-family="JetBrains Mono, monospace" font-size="15" fill="#5B6B7C" text-anchor="middle">${label}</text>` : ""}
</svg>`;
  }

  window.HAND = HAND;
  window.Art = { handSVG, lancetSVG, stripSVG };
})();
