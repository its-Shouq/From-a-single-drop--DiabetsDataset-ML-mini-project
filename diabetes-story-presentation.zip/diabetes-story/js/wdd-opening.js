/* ==========================================================================
   wdd-opening.js — World Diabetes Day prelude for slide 1.
   Particles gather into the blue awareness circle, "14 November · World
   Diabetes Day" appears, the circle pulses and unrolls into the heartbeat
   line where the ORIGINAL opening animation begins. The original slide 1
   timeline is untouched: it simply starts W seconds later, so Replay and
   Skip cover the whole sequence.
   ========================================================================== */
(function () {
  const { clamp, lerp, seg, ease, rng, mix, $, rise } = K;
  const S = SCENES[0];
  const W = 6.6;                                   // prelude length (s)
  const baseInit = S.init, baseUpdate = S.update;
  const CX = 960, CY = 450, RING = 150, BASE_Y = 540;
  const BLUE = "#2E8FE0", BLUE_HI = "#6FB8FF", CYAN = "#5BE3F0";

  S.duration += W;

  S.init = function (api) {
    baseInit.call(this, api);
    const s = this.s;
    this.wDate = $(".wdd-date", s); this.wName = $(".wdd-name", s);
    this.wDate.style.top = (CY - 92) + "px";
    this.wName.style.top = (CY + RING + 70) + "px";
    const R = rng(14), N = 210, P = this.wP = [];
    for (let i = 0; i < N; i++) {
      const a = i / N * 6.2832 + (R() - .5) * .05, rr = RING + (R() - .5) * 26;
      const sa = R() * 6.2832, sd = lerp(420, 1100, Math.sqrt(R()));
      P.push({
        a, rr,
        sx: CX + Math.cos(sa) * sd * 1.3, sy: CY + Math.sin(sa) * sd * .75,     // where it drifts in from
        bx: lerp(-30, 1950, R()), by: BASE_Y + (R() - .5) * 10,               // its place on the heartbeat baseline
        d: R(), col: i % 3 === 0 ? CYAN : i % 3 === 1 ? BLUE_HI : BLUE, r: lerp(1.4, 3.0, R()), sw: R() * 6.28
      });
    }
  };

  S.update = function (t) {
    const tt = t - W;
    baseUpdate.call(this, Math.max(0, tt));          // the original opening (held at its first frame during the prelude)
    const fx = this.fx, g = fx.g;

    /* --- text --- */
    const tin = seg(t, 2.7, 3.6), nin = seg(t, 3.3, 4.3), tout = ease.inOut(seg(t, 4.9, 5.6));
    rise(this.wDate, tin, 18); rise(this.wName, nin, 18);
    if (tout > 0) [this.wDate, this.wName].forEach(e => {
      e.style.opacity = (Math.min(+e.style.opacity, 1 - tout)).toFixed(3);
      e.style.filter = `blur(${(6 * tout).toFixed(1)}px)`;
    });
    else [this.wDate, this.wName].forEach(e => e.style.filter = "");

    if (tt > 2.2) return;                            // prelude fully handed over

    /* --- soft central light --- */
    const lightK = seg(t, 0, 1.4) * (1 - seg(t, 5.0, 6.4));
    if (lightK > 0) {
      const gr = g.createRadialGradient(CX, CY, 0, CX, CY, 460);
      gr.addColorStop(0, `rgba(46,143,224,${(.28 * lightK).toFixed(3)})`);
      gr.addColorStop(1, "rgba(46,143,224,0)");
      g.fillStyle = gr; g.fillRect(CX - 460, CY - 460, 920, 920);
    }

    /* --- the luminous blue circle --- */
    const ringK = ease.out(seg(t, 2.1, 3.0)), pulse = seg(t, 4.3, 5.4), ringOut = ease.inOut(seg(t, 5.0, 5.7));
    const flash = Math.sin(Math.PI * seg(t, 4.3, 4.8));
    const ringA = ringK * (1 - ringOut);
    if (ringA > 0) {
      g.save();
      g.globalAlpha = .14 * ringA * (1 + flash); g.strokeStyle = BLUE_HI; g.lineWidth = 70;
      g.beginPath(); g.arc(CX, CY, RING, 0, 6.2832); g.stroke();
      g.globalAlpha = .92 * ringA; g.strokeStyle = BLUE; g.lineWidth = 30;
      g.shadowColor = "rgba(91,170,255,.8)"; g.shadowBlur = 26 + 20 * flash;
      g.beginPath(); g.arc(CX, CY, RING, 0, 6.2832); g.stroke();
      g.shadowBlur = 0; g.globalAlpha = .35 * ringA; g.strokeStyle = "#CFE8FF"; g.lineWidth = 2;
      g.beginPath(); g.arc(CX, CY, RING - 9, 3.6, 5.6); g.stroke();
      g.restore();
    }
    /* --- the pulse of light leaves the circle --- */
    if (pulse > 0 && pulse < 1) {
      const pr = RING + 1100 * ease.out(pulse);
      g.globalAlpha = .5 * (1 - pulse); g.strokeStyle = CYAN; g.lineWidth = 2.5;
      g.beginPath(); g.arc(CX, CY, pr, 0, 6.2832); g.stroke(); g.globalAlpha = 1;
    }

    /* --- particles: gather → circle → unroll into the heartbeat line --- */
    const head = -20 + 1960 * ease.inOutSine(seg(Math.max(0, tt), .2, 2.6));   // head of the original ECG trace
    const spin = t * .06;
    for (const p of this.wP) {
      const gk = ease.inOut(clamp((t - .5 - p.d * 1.1) / 1.7));
      const a = p.a + spin;
      let x = lerp(p.sx, CX + Math.cos(a) * p.rr, gk), y = lerp(p.sy, CY + Math.sin(a) * p.rr, gk);
      // a gentle swirl while they travel
      const sw = Math.sin(gk * Math.PI) * 40;
      x += Math.cos(p.sw + t) * sw; y += Math.sin(p.sw + t) * sw;
      const uk = ease.inOut(clamp((t - 5.1 - p.d * .7) / 1.1));
      x = lerp(x, p.bx, uk); y = lerp(y, p.by, uk);
      let al = clamp((t - .3 - p.d * .8) / .8) * (.55 + .45 * Math.sin(t * 2 + p.sw) ** 2);
      al *= 1 - .5 * ringK * (1 - uk);                // the solid circle takes over visually
      if (uk > 0) al = Math.max(al, .5 * uk);
      if (tt > 0 && x < head) al *= clamp(1 - (head - x) / 160);   // the heartbeat consumes the dotted line
      fx.glow(x, y, p.r * (1 - .3 * uk), uk > .5 ? CYAN : p.col, al);
    }
  };
})();
