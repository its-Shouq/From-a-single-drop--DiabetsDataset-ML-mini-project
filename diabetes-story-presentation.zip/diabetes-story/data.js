/* ==========================================================================
   data.js — every number shown in the presentation.
   Source of truth: "Diabetes_Decision_Tree (1).ipynb"
   Dataset: Diabetes Dataset, Mendeley Data (https://data.mendeley.com/datasets/wj9rwkp9c2/1)
   ========================================================================== */
window.DATA = {
  source: "Diabetes Dataset — Mendeley Data",

  /* --- Dataset (notebook cells 7, 8, 28) --- */
  records: 1000,
  columns: 14,
  classes: [
    { key: "N", name: "غير مصاب بالسكري", en: "Non-diabetic", count: 103, pct: 10.3 },
    { key: "P", name: "ما قبل السكري", en: "Pre-diabetic", count: 53, pct: 5.3 },
    { key: "Y", name: "مصاب بالسكري", en: "Diabetic", count: 844, pct: 84.4 }
  ],

  /* --- Class means after label cleaning, all 1,000 rows (cells 38, 39) --- */
  hba1c: {
    N: { mean: 4.56, min: 0.9, max: 5.6 },
    P: { mean: 6.0, min: 5.7, max: 6.4 },
    Y: { mean: 8.88, min: 2.0, max: 16.0 }
  },
  bmi: { N: 22.37, P: 23.93, Y: 30.81 },
  age: { N: 44.23, P: 43.28, Y: 55.31 },

  /* --- Column guide + overall means (cells 8, 11, 18) --- */
  features: [
    { id: "HbA1c", label: "السكر التراكمي", abbr: "HbA1c", group: "sugar", mean: "8.28", note: "قياس لمستوى سكر الدم." },
    { id: "BMI", label: "مؤشر كتلة الجسم", abbr: "BMI", group: "body", mean: "29.58", note: "مؤشر كتلة الجسم، وهو أعلى في المتوسط لدى المصابين." },
    { id: "Age", label: "العمر", group: "body", mean: "53.5", note: "العمر بالسنوات، والمصابون أكبر سنًّا في المتوسط." },
    { id: "Gender", label: "الجنس", group: "body", mean: "M 565 · F 435", note: "مسجّل بالرمزين M / F، ويُحوَّل إلى 0 / 1 للنموذج." },
    { id: "TG", label: "الدهون الثلاثية", group: "lipid", mean: "2.35", note: "الدهون الثلاثية، وهي أعلى لدى المصابين." },
    { id: "VLDL", label: "VLDL", group: "lipid", mean: "1.85", note: "بروتين دهني منخفض الكثافة جدًا، وهو أعلى لدى المصابين." },
    { id: "Chol", label: "الكوليسترول", group: "lipid", mean: "4.86", note: "الكوليسترول الكلي، متقارب بين الفئات." },
    { id: "HDL", label: "HDL", group: "lipid", mean: "1.20", note: "الكوليسترول «النافع»، متقارب بين الفئات." },
    { id: "LDL", label: "LDL", group: "lipid", mean: "2.61", note: "الكوليسترول «الضار»، متقارب بين الفئات." },
    { id: "Urea", label: "اليوريا", group: "kidney", mean: "5.12", note: "من فحوصات وظائف الكلى، متقارب بين الفئات." },
    { id: "Cr", label: "الكرياتينين", group: "kidney", mean: "68.9", note: "من فحوصات الكلى، وتوزيعه منحرف بشدة (أعلى قيمة 800)." }
  ],

  /* --- Preprocessing (cells 13–17, 56, 59, 62, 66) --- */
  prep: {
    duplicatesRemoved: 174,
    zeroCholRemoved: 1,
    cleanRows: 825,
    cleanCounts: { Y: 690, N: 96, P: 40 },
    features: 11,
    train: 660,
    test: 165
  },

  /* --- Depth search, 5-fold CV mean macro-F1 on training set (cell 70) --- */
  depthCV: [0.534, 0.768, 0.866, 0.926, 0.947, 0.936, 0.917, 0.921, 0.921, 0.921],
  chosenDepth: 5,

  /* --- Test-set results, 165 records (cells 68, 72) --- */
  models: {
    lr: {
      name: "Logistic Regression", role: "Baseline",
      accuracy: 93.9, macroF1: 74.2, precision: 83.7, recall: 71.0, pRecall: 25.0,
      cm: [[17, 0, 2], [1, 2, 5], [1, 1, 136]]
    },
    dt: {
      name: "Decision Tree", role: "Main model",
      accuracy: 98.8, macroF1: 97.9, precision: 99.5, recall: 96.5, pRecall: 100.0,
      cm: [[17, 0, 2], [0, 8, 0], [0, 0, 138]]
    }
  },

  /* --- The trained Decision Tree (max_depth = 5), transcribed from plot_tree (cell 76).
         value = training samples per class [N, P, Y]. Left child = condition True. --- */
  tree: {
    id: 0, f: "HbA1c", t: 6.25, v: [76, 32, 552],
    L: { id: 1, f: "HbA1c", t: 5.65, v: [76, 28, 49],
      L: { id: 2, f: "Cholesterol", t: 4.95, v: [76, 0, 36],
        L: { id: 3, f: "BMI", t: 24.8, v: [66, 0, 8],
          L: { id: 4, v: [66, 0, 0] },
          R: { id: 5, v: [0, 0, 8] } },
        R: { id: 6, f: "Triglycerides", t: 1.55, v: [10, 0, 28],
          L: { id: 7, f: "Creatinine", t: 77.0, v: [8, 0, 4],
            L: { id: 8, v: [8, 0, 1] },
            R: { id: 9, v: [0, 0, 3] } },
          R: { id: 10, f: "Creatinine", t: 119.0, v: [2, 0, 24],
            L: { id: 11, v: [1, 0, 24] },
            R: { id: 12, v: [1, 0, 0] } } } },
      R: { id: 13, f: "Age", t: 50.5, v: [0, 28, 13],
        L: { id: 14, v: [0, 26, 0] },
        R: { id: 15, f: "Triglycerides", t: 2.8, v: [0, 2, 13],
          L: { id: 16, v: [0, 0, 13] },
          R: { id: 17, v: [0, 2, 0] } } } },
    R: { id: 18, f: "HbA1c", t: 6.45, v: [0, 4, 503],
      L: { id: 19, f: "Age", t: 49.0, v: [0, 4, 7],
        L: { id: 20, v: [0, 4, 0] },
        R: { id: 21, v: [0, 0, 7] } },
      R: { id: 22, v: [0, 0, 496] } }
  }
};
